/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  Umbrella, Waves, Flame, Award, Users, Star, Compass, Phone, MessageSquare, 
  Send, Search, Grid, List, CheckCircle, Info, MapPin, Heart, BookOpen, 
  Clock, ShieldCheck, Mail, RefreshCw, Key, X, ChevronDown, ChevronUp, Lock, FileDown
} from 'lucide-react';

import { jsPDF } from 'jspdf';

import { Property, Booking, Review, Blog, User, WebsiteSettings } from './types';
import { INITIAL_PROPERTIES } from './data/properties';
import { INITIAL_BLOGS } from './data/blogs';
import { INITIAL_REVIEWS } from './data/reviews';

import Navbar from './components/Navbar';
import Footer from './components/Footer';
import PropertyCard from './components/PropertyCard';
import PropertyDetails from './components/PropertyDetails';
import AdminPanel from './components/AdminPanel';

// Default Website Settings
const DEFAULT_SETTINGS: WebsiteSettings = {
  siteName: 'Hawksbay Beach House',
  phone: '+92 300 1234567',
  whatsapp: '923001234567',
  email: 'info@hawksbaybeachhouse.com',
  address: 'Hawksbay Shoreline Road, Block B, Mauripur, Karachi, Pakistan',
  headerText: 'Premium Beach House Rentals in Karachi',
  footerText: '© 2026 Hawksbay Beach House. All Rights Reserved. Managed professionally for premium coastal bookings.'
};

// Seed Bookings
const SEED_BOOKINGS: Booking[] = [
  {
    id: 'BK-789021',
    propertyId: 'hb-01',
    propertyName: 'The Azure Sands Retreat',
    checkIn: '2026-07-15',
    checkOut: '2026-07-17',
    guests: 20,
    totalPrice: 130000,
    guestName: 'Sarmad Alvi',
    guestEmail: 'sarmad@domain.com',
    guestPhone: '+92 300 9876543',
    status: 'Approved',
    paymentStatus: 'Paid',
    createdAt: '2026-07-01'
  },
  {
    id: 'BK-542103',
    propertyId: 'hb-02',
    propertyName: 'La Serena Cove',
    checkIn: '2026-07-22',
    checkOut: '2026-07-24',
    guests: 12,
    totalPrice: 90000,
    guestName: 'Fiza Ahmed',
    guestEmail: 'fiza@outlook.com',
    guestPhone: '+92 321 4567890',
    status: 'Pending',
    paymentStatus: 'Pending',
    createdAt: '2026-07-02'
  },
  {
    id: 'BK-123456',
    propertyId: 'hb-03',
    propertyName: 'Turtle Beach Royal Pavilion',
    checkIn: '2026-07-29',
    checkOut: '2026-07-30',
    guests: 25,
    totalPrice: 85000,
    guestName: 'Zubair Chawla',
    guestEmail: 'zubair@chawla.com',
    guestPhone: '+92 333 1122334',
    status: 'Approved',
    paymentStatus: 'Partially Paid',
    createdAt: '2026-07-03'
  }
];

export default function App() {
  // State Initialization from localStorage or defaults
  const [properties, setProperties] = useState<Property[]>(() => {
    const saved = localStorage.getItem('hbb_properties');
    return saved ? JSON.parse(saved) : INITIAL_PROPERTIES;
  });

  const [bookings, setBookings] = useState<Booking[]>(() => {
    const saved = localStorage.getItem('hbb_bookings');
    return saved ? JSON.parse(saved) : SEED_BOOKINGS;
  });

  const [reviews, setReviews] = useState<Review[]>(() => {
    const saved = localStorage.getItem('hbb_reviews');
    return saved ? JSON.parse(saved) : INITIAL_REVIEWS;
  });

  const [blogs, setBlogs] = useState<Blog[]>(() => {
    const saved = localStorage.getItem('hbb_blogs');
    return saved ? JSON.parse(saved) : INITIAL_BLOGS;
  });

  const [settings, setSettings] = useState<WebsiteSettings>(() => {
    const saved = localStorage.getItem('hbb_settings');
    return saved ? JSON.parse(saved) : DEFAULT_SETTINGS;
  });

  const [favorites, setFavorites] = useState<string[]>(() => {
    const saved = localStorage.getItem('hbb_favorites');
    return saved ? JSON.parse(saved) : ['hb-01', 'hb-03'];
  });

  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('hbb_user');
    return saved ? JSON.parse(saved) : null; // Visitor by default
  });

  const [currentRole, setCurrentRole] = useState<'User' | 'Moderator' | 'Admin'>(() => {
    const savedUser = localStorage.getItem('hbb_user');
    if (savedUser) {
      const parsed = JSON.parse(savedUser) as User;
      return parsed.role;
    }
    return 'User'; // Visitor by default
  });

  const [activeTab, setActiveTab] = useState<string>('home');
  const [selectedPropertyId, setSelectedPropertyId] = useState<string | null>(null);
  const [selectedBlogId, setSelectedBlogId] = useState<string | null>(null);

  // General App Notifications
  const [notification, setNotification] = useState<string | null>(null);

  // New Modals
  const [showPrivacyModal, setShowPrivacyModal] = useState(false);
  const [showTermsModal, setShowTermsModal] = useState(false);
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(null);

  // Login error state
  const [authError, setAuthError] = useState<string | null>(null);

  // Filter States
  const [searchLocation, setSearchLocation] = useState('');
  const [searchPriceMax, setSearchPriceMax] = useState(120000);
  const [searchBedrooms, setSearchBedrooms] = useState('any');
  const [searchCapacity, setSearchCapacity] = useState('any');
  const [filterPool, setFilterPool] = useState(false);
  const [filterBBQ, setFilterBBQ] = useState(false);
  const [filterBeachView, setFilterBeachView] = useState(false);
  const [filterFamily, setFilterFamily] = useState(false);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');

  // Login Modal states
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');
  const [isRegistering, setIsRegistering] = useState(false);
  const [registerName, setRegisterName] = useState('');

  // Contact Form state
  const [contactName, setContactName] = useState('');
  const [contactPhone, setContactPhone] = useState('');
  const [contactMsg, setContactMsg] = useState('');
  const [contactSuccess, setContactSuccess] = useState(false);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem('hbb_properties', JSON.stringify(properties));
  }, [properties]);

  useEffect(() => {
    localStorage.setItem('hbb_bookings', JSON.stringify(bookings));
  }, [bookings]);

  useEffect(() => {
    localStorage.setItem('hbb_reviews', JSON.stringify(reviews));
  }, [reviews]);

  useEffect(() => {
    localStorage.setItem('hbb_blogs', JSON.stringify(blogs));
  }, [blogs]);

  useEffect(() => {
    localStorage.setItem('hbb_settings', JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem('hbb_favorites', JSON.stringify(favorites));
  }, [favorites]);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('hbb_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('hbb_user');
    }
  }, [currentUser]);

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => {
      setNotification(null);
    }, 4000);
  };

  const handleToggleFavorite = (propId: string, e?: React.MouseEvent) => {
    if (e) e.stopPropagation();
    setFavorites(prev => 
      prev.includes(propId) ? prev.filter(id => id !== propId) : [...prev, propId]
    );
  };

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    if (isRegistering) {
      if (!registerName || !loginEmail || !loginPassword) {
        setAuthError('All registration fields are required');
        return;
      }
      const newUser: User = {
        id: 'u-' + Math.floor(Math.random() * 10000),
        email: loginEmail,
        name: registerName,
        role: 'User'
      };
      setCurrentUser(newUser);
      setCurrentRole('User');
      setShowLoginModal(false);
      showNotification('Your account has been registered successfully!');
    } else {
      if (!loginEmail || !loginPassword) {
        setAuthError('Email and password credentials are required');
        return;
      }
      
      let role: 'User' | 'Moderator' | 'Admin' = 'User';
      let name = 'Valued Customer';
      
      if (loginEmail === 'admin@hawksbay.com') {
        if (loginPassword !== 'admin123') {
          setAuthError('Invalid administrator password');
          return;
        }
        role = 'Admin';
        name = 'Super Admin';
      } else if (loginEmail === 'mod@hawksbay.com') {
        if (loginPassword !== 'mod123') {
          setAuthError('Invalid moderator password');
          return;
        }
        role = 'Moderator';
        name = 'Beach Moderator';
      } else {
        // Fallback for custom user sign ins
        role = 'User';
        name = loginEmail.split('@')[0];
      }
      
      setCurrentUser({ id: 'u-logged', email: loginEmail, name, role });
      setCurrentRole(role);
      setShowLoginModal(false);
      showNotification(`Welcome back, ${name}! Logged in successfully.`);
    }
    setLoginEmail('');
    setLoginPassword('');
    setRegisterName('');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentRole('User');
    setActiveTab('home');
    showNotification('You have logged out of the portal successfully.');
  };

  // Submit new booking request
  const handleBookingSubmit = (bookingData: any) => {
    const property = properties.find(p => p.id === bookingData.propertyId);
    const date1 = new Date(bookingData.checkIn);
    const date2 = new Date(bookingData.checkOut);
    const diffNights = Math.ceil(Math.abs(date2.getTime() - date1.getTime()) / (1000 * 60 * 60 * 24));
    const nightsCount = diffNights > 0 ? diffNights : 1;
    const totalPrice = nightsCount * (property?.pricePerNight || 40000);

    const newBooking: Booking = {
      id: 'BK-' + Math.floor(100000 + Math.random() * 900000),
      propertyId: bookingData.propertyId,
      propertyName: property?.title || 'Hawksbay Beach Cabin',
      checkIn: bookingData.checkIn,
      checkOut: bookingData.checkOut,
      guests: bookingData.guests,
      totalPrice,
      guestName: bookingData.guestName,
      guestEmail: bookingData.guestEmail,
      guestPhone: bookingData.guestPhone,
      status: 'Pending',
      paymentStatus: 'Pending',
      createdAt: new Date().toISOString().split('T')[0]
    };

    setBookings(prev => [newBooking, ...prev]);
    showNotification('Booking request submitted! Our team will contact you shortly.');
  };

  // Cancel booking
  const handleCancelBooking = (bookingId: string) => {
    if (confirm('Are you sure you want to cancel this booking request?')) {
      setBookings(prev => prev.filter(b => b.id !== bookingId));
      showNotification('Booking request has been canceled successfully.');
    }
  };

  // Submit review
  const handleReviewSubmit = (reviewData: any) => {
    const property = properties.find(p => p.id === reviewData.propertyId);
    const newReview: Review = {
      id: 'rev-' + (reviews.length + 1),
      propertyId: reviewData.propertyId,
      propertyName: property?.title || 'Beach House',
      authorName: reviewData.authorName,
      rating: reviewData.rating,
      comment: reviewData.comment,
      approved: false, // Must be approved by moderator/admin!
      createdAt: new Date().toISOString().split('T')[0]
    };

    setReviews(prev => [newReview, ...prev]);
    showNotification('Review submitted! It will appear publicly after moderation.');
  };

  // Download booking summary as formatted PDF
  const handleDownloadPDF = (booking: Booking) => {
    try {
      const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });

      // Color palette
      const primaryColor = [14, 165, 233]; // sky-500
      const secondaryColor = [15, 23, 42]; // slate-900
      const textColor = [71, 85, 105]; // slate-600
      const lightBgColor = [248, 250, 252]; // slate-50

      // Header Banner Background
      doc.setFillColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
      doc.rect(0, 0, 210, 40, 'F');

      // Decorative Accent Bar
      doc.setFillColor(primaryColor[0], primaryColor[1], primaryColor[2]);
      doc.rect(0, 40, 210, 3, 'F');

      // Header Title
      doc.setTextColor(255, 255, 255);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(22);
      doc.text('HAWKSBAY BEACH HOUSE', 15, 18);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(10);
      doc.setTextColor(186, 230, 253); // sky-200
      doc.text('Premium Beach House Rentals in Karachi', 15, 24);
      doc.text('Email: info@hawksbaybeachhouse.com | Phone: +92 300 1234567', 15, 30);

      // Document Type / Booking Status Badge
      doc.setFillColor(240, 253, 250); // emerald-50
      doc.rect(148, 12, 47, 16, 'F');
      doc.setDrawColor(16, 185, 129); // emerald-500
      doc.setLineWidth(0.5);
      doc.rect(148, 12, 47, 16, 'D');

      doc.setTextColor(4, 120, 87); // emerald-700
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      doc.text('CONFIRMED', 171.5, 18.5, { align: 'center' });
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.text('BOOKING SUMMARY', 171.5, 23.5, { align: 'center' });

      // Main Content Section
      let y = 55;

      // Booking Reference
      doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(14);
      doc.text('Reservation details', 15, y);

      // Divider
      y += 3;
      doc.setDrawColor(226, 232, 240); // slate-200
      doc.setLineWidth(0.5);
      doc.line(15, y, 195, y);

      // General Booking details grid (Left: Guest info, Right: Stay details)
      y += 10;

      // Column 1 (Left): Guest Info
      doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10);
      doc.text('GUEST DETAILS', 15, y);

      doc.setTextColor(textColor[0], textColor[1], textColor[2]);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(10);
      y += 6;
      doc.text(`Name: ${booking.guestName}`, 15, y);
      y += 6;
      doc.text(`Email: ${booking.guestEmail}`, 15, y);
      y += 6;
      doc.text(`Phone: ${booking.guestPhone}`, 15, y);

      // Reset y for Column 2
      let rY = y - 18;
      // Column 2 (Right): Stay Info
      doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10);
      doc.text('STAY DETAILS', 110, rY);

      doc.setTextColor(textColor[0], textColor[1], textColor[2]);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(10);
      rY += 6;
      doc.text(`Booking ID: ${booking.id}`, 110, rY);
      rY += 6;
      doc.text(`Check-In: ${booking.checkIn}`, 110, rY);
      rY += 6;
      doc.text(`Check-Out: ${booking.checkOut}`, 110, rY);

      // Update y to the lowest point
      y = Math.max(y, rY) + 12;

      // Property & Pricing Section
      doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(14);
      doc.text('Accommodation details', 15, y);

      // Divider
      y += 3;
      doc.line(15, y, 195, y);

      y += 8;
      // Table Header
      doc.setFillColor(lightBgColor[0], lightBgColor[1], lightBgColor[2]);
      doc.rect(15, y, 180, 10, 'F');

      doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      doc.text('Description', 18, y + 6.5);
      doc.text('Details', 110, y + 6.5);
      doc.text('Amount (PKR)', 192, y + 6.5, { align: 'right' });

      // Table Body Rows
      y += 10;

      // Row 1: Property Name
      doc.setTextColor(textColor[0], textColor[1], textColor[2]);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(10);
      doc.text('Property Name', 18, y + 6);
      doc.setFont('helvetica', 'bold');
      doc.text(booking.propertyName, 110, y + 6);
      doc.line(15, y + 10, 195, y + 10);
      y += 10;

      // Row 2: Guests Count
      doc.setFont('helvetica', 'normal');
      doc.text('Total Guests', 18, y + 6);
      doc.text(`${booking.guests} Guests`, 110, y + 6);
      doc.line(15, y + 10, 195, y + 10);
      y += 10;

      // Row 3: Stay Duration
      const checkInDate = new Date(booking.checkIn);
      const checkOutDate = new Date(booking.checkOut);
      const diffTime = Math.abs(checkOutDate.getTime() - checkInDate.getTime());
      const diffDays = Math.max(1, Math.ceil(diffTime / (1000 * 60 * 60 * 24)));

      doc.setFont('helvetica', 'normal');
      doc.text('Stay Duration', 18, y + 6);
      doc.text(`${diffDays} Night(s)`, 110, y + 6);
      doc.line(15, y + 10, 195, y + 10);
      y += 10;

      // Row 4: Pricing Status
      doc.setFont('helvetica', 'normal');
      doc.text('Payment Status', 18, y + 6);
      doc.setFont('helvetica', 'bold');
      doc.text(booking.paymentStatus, 110, y + 6);
      doc.line(15, y + 10, 195, y + 10);
      y += 10;

      // Row 5: Total Amount Row
      doc.setFillColor(lightBgColor[0], lightBgColor[1], lightBgColor[2]);
      doc.rect(15, y, 180, 12, 'F');
      doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(11);
      doc.text('Total Amount Paid / Due', 18, y + 7.5);
      doc.text(`PKR ${booking.totalPrice.toLocaleString()}`, 192, y + 7.5, { align: 'right' });
      y += 20;

      // Important Guidelines / Notice Box
      doc.setFillColor(248, 250, 252); // slate-50
      doc.rect(15, y, 180, 32, 'F');
      doc.setDrawColor(226, 232, 240); // slate-200
      doc.setLineWidth(0.5);
      doc.rect(15, y, 180, 32, 'D');

      doc.setTextColor(secondaryColor[0], secondaryColor[1], secondaryColor[2]);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      doc.text('IMPORTANT GUEST INSTRUCTIONS:', 20, y + 6);

      doc.setTextColor(textColor[0], textColor[1], textColor[2]);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.text('1. Please carry a copy of this printed Booking Summary and original CNICs of all adult guests for verification.', 20, y + 12);
      doc.text('2. Standard Check-In is at 12:00 PM (Noon), and Check-Out is at 10:00 AM on the respective dates.', 20, y + 18);
      doc.text('3. Swimming in the sea is subject to local tide conditions and Sindh Government safety directives.', 20, y + 24);

      // Footer Branding
      y = 270;
      doc.setDrawColor(226, 232, 240);
      doc.line(15, y, 195, y);

      doc.setTextColor(148, 163, 184); // slate-400
      doc.setFontSize(8);
      doc.text('Thank you for choosing Hawksbay Beach House. Have a magnificent coastal retreat!', 15, y + 6);
      doc.text('Page 1 of 1', 195, y + 6, { align: 'right' });

      // Save the PDF
      doc.save(`Hawksbay_Booking_${booking.id}.pdf`);
      showNotification('Booking summary downloaded successfully as PDF!');
    } catch (err) {
      console.error('PDF Generation Error:', err);
      showNotification('Failed to generate PDF. Please try again.');
    }
  };

  // Contact form handler
  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!contactName || !contactPhone || !contactMsg) {
      setNotification('All contact form fields are required.');
      return;
    }
    setContactSuccess(true);
    setContactName('');
    setContactPhone('');
    setContactMsg('');
    setTimeout(() => setContactSuccess(false), 5000);
  };

  // Admin status update handlers
  const handleUpdateBookingStatus = (bookingId: string, status: Booking['status']) => {
    setBookings(prev => prev.map(b => b.id === bookingId ? { ...b, status } : b));
    showNotification(`Booking status updated to ${status}.`);
  };

  const handleUpdatePaymentStatus = (bookingId: string, paymentStatus: Booking['paymentStatus']) => {
    setBookings(prev => prev.map(b => b.id === bookingId ? { ...b, paymentStatus } : b));
    showNotification(`Payment status updated to ${paymentStatus}.`);
  };

  const handleApproveReview = (reviewId: string) => {
    setReviews(prev => prev.map(r => r.id === reviewId ? { ...r, approved: true } : r));
    showNotification('Review approved and published successfully.');
  };

  const handleDeleteReview = (reviewId: string) => {
    if (confirm('Delete this review permanently?')) {
      setReviews(prev => prev.filter(r => r.id !== reviewId));
    }
  };

  const handleAddProperty = (newProperty: Property) => {
    setProperties(prev => [newProperty, ...prev]);
  };

  const handleDeleteProperty = (propertyId: string) => {
    if (confirm('Delete this listing permanently?')) {
      setProperties(prev => prev.filter(p => p.id !== propertyId));
    }
  };

  const handleAddBlog = (newBlog: Blog) => {
    setBlogs(prev => [newBlog, ...prev]);
  };

  const handleDeleteBlog = (blogId: string) => {
    if (confirm('Delete this article?')) {
      setBlogs(prev => prev.filter(b => b.id !== blogId));
    }
  };

  // Filter Logic
  const filteredProperties = properties.filter(prop => {
    const matchLocation = !searchLocation || prop.location.toLowerCase().includes(searchLocation.toLowerCase());
    const matchPrice = prop.pricePerNight <= searchPriceMax;
    const matchBedrooms = searchBedrooms === 'any' || prop.bedrooms >= Number(searchBedrooms);
    const matchCapacity = searchCapacity === 'any' || prop.guestCapacity >= Number(searchCapacity);
    const matchPool = !filterPool || prop.hasPool;
    const matchBBQ = !filterBBQ || prop.hasBBQ;
    const matchBeachView = !filterBeachView || prop.hasBeachView;
    const matchFamily = !filterFamily || prop.isFamilyFriendly;

    return matchLocation && matchPrice && matchBedrooms && matchCapacity && matchPool && matchBBQ && matchBeachView && matchFamily;
  });

  // Featured Properties for home screen
  const featuredProperties = properties.filter(p => p.featured).slice(0, 3);
  const activeSelectedProperty = properties.find(p => p.id === selectedPropertyId);
  const activeSelectedBlog = blogs.find(b => b.id === selectedBlogId);

  return (
    <div className="bg-slate-50 text-slate-800 font-sans min-h-screen flex flex-col selection:bg-sky-200 selection:text-sky-900">
      
      {/* Header Navigation Section */}
      <Navbar
        currentUser={currentUser}
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setActiveTab(tab);
          setSelectedPropertyId(null);
          setSelectedBlogId(null);
        }}
        onLoginClick={() => {
          setIsRegistering(false);
          setShowLoginModal(true);
        }}
        onLogout={handleLogout}
      />

      {/* Global Toast Notification */}
      {notification && (
        <div className="fixed top-24 right-6 z-50 bg-slate-900 text-white border border-slate-800 px-5 py-4 rounded-2xl shadow-2xl flex items-center gap-3 font-bold text-xs animate-bounce">
          <CheckCircle size={16} className="text-emerald-400 shrink-0" />
          <span>{notification}</span>
        </div>
      )}

      {/* Main Page Area Router */}
      <main className="flex-1">
        
        {/* Detail page overlays (Backing as individual sub-pages) */}
        {selectedPropertyId && activeSelectedProperty && (
          <PropertyDetails
            property={activeSelectedProperty}
            onBack={() => setSelectedPropertyId(null)}
            reviews={reviews}
            onSubmitBooking={handleBookingSubmit}
            onSubmitReview={handleReviewSubmit}
            isFavorite={favorites.includes(activeSelectedProperty.id)}
            onToggleFavorite={(id) => handleToggleFavorite(id)}
          />
        )}

        {selectedBlogId && activeSelectedBlog && (
          <div className="max-w-4xl mx-auto px-6 py-12 space-y-8">
            <button
              onClick={() => setSelectedBlogId(null)}
              className="flex items-center gap-2 font-bold text-sm text-slate-500 hover:text-sky-600 transition"
            >
              ← Back to Blogs List
            </button>
            <div className="space-y-4">
              <span className="bg-sky-100 text-sky-800 text-[10px] font-bold px-3 py-1 rounded-md uppercase tracking-wider">
                {activeSelectedBlog.category}
              </span>
              <h1 className="text-3xl lg:text-4xl font-extrabold text-slate-900 tracking-tight">
                {activeSelectedBlog.title}
              </h1>
              <div className="flex items-center gap-4 text-xs font-semibold text-slate-400">
                <span>By {activeSelectedBlog.author}</span>
                <span>•</span>
                <span>{activeSelectedBlog.date}</span>
                <span>•</span>
                <span>{activeSelectedBlog.readTime}</span>
              </div>
            </div>
            <div className="rounded-3xl overflow-hidden h-[380px] shadow-sm">
              <img src={activeSelectedBlog.image} alt={activeSelectedBlog.title} className="w-full h-full object-cover" />
            </div>
            {/* Blog article text body */}
            <div className="bg-white p-8 lg:p-10 rounded-3xl border border-slate-100 shadow-sm leading-relaxed text-slate-600 space-y-6 text-base whitespace-pre-line">
              {activeSelectedBlog.content}
            </div>
            <div className="flex flex-wrap gap-2 pt-2">
              {activeSelectedBlog.tags.map(tag => (
                <span key={tag} className="bg-slate-100 text-slate-600 text-xs font-bold px-3 py-1 rounded-xl">
                  #{tag}
                </span>
              ))}
            </div>
          </div>
        )}

        {/* Regular Tabs (Displayed if no detailed entity is active) */}
        {!selectedPropertyId && !selectedBlogId && (
          <>
            {/* A. HOMEPAGE TAB */}
            {activeTab === 'home' && (
              <div className="space-y-20 pb-20">
                {/* Hero Section */}
                <section className="relative h-[600px] bg-slate-900 text-white flex items-center justify-center overflow-hidden">
                  <div className="absolute inset-0 z-0 opacity-40">
                    <img
                      src="https://images.unsplash.com/photo-1499793983690-e29da59ef1c2?auto=format&fit=crop&w=1920&q=80"
                      alt="Karachi Beach Resort"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-slate-900/40 z-10"></div>
                  
                  <div className="relative z-20 max-w-4xl mx-auto px-6 text-center space-y-6">
                    <span className="text-sky-300 font-extrabold uppercase tracking-widest text-xs">Coastal Getaway Sanctuary</span>
                    <h2 className="text-4xl lg:text-6xl font-black tracking-tight leading-tight">
                      Find Your Ultimate Beach House in Karachi
                    </h2>
                    <p className="text-base lg:text-lg text-slate-200 max-w-2xl mx-auto font-medium leading-relaxed">
                      Experience exclusive, pristine beachfront compounds at Hawksbay, Sandspit, Turtle Beach, and French Beach with luxury private swimming pools and secure facilities.
                    </p>

                    {/* Quick Horizontal Search Bar */}
                    <div className="bg-white p-3 rounded-2xl md:rounded-full shadow-2xl flex flex-col md:flex-row gap-3 max-w-3xl mx-auto text-slate-800">
                      <div className="flex-1 text-left px-5 py-1">
                        <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Destination</label>
                        <select 
                          value={searchLocation} 
                          onChange={(e) => setSearchLocation(e.target.value)}
                          className="w-full bg-transparent border-none outline-none focus:ring-0 text-slate-900 font-bold text-xs py-1 cursor-pointer"
                        >
                          <option value="">All Karachi Beaches</option>
                          <option value="Hawksbay">Hawksbay Beach</option>
                          <option value="Sandspit">Sandspit Beach</option>
                          <option value="Turtle">Turtle Beach</option>
                          <option value="French">French Beach</option>
                        </select>
                      </div>
                      <div className="hidden md:block w-px h-10 bg-slate-100 self-center"></div>
                      <div className="flex-1 text-left px-5 py-1">
                        <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Max Price</label>
                        <select 
                          value={searchPriceMax} 
                          onChange={(e) => setSearchPriceMax(Number(e.target.value))}
                          className="w-full bg-transparent border-none outline-none focus:ring-0 text-slate-900 font-bold text-xs py-1 cursor-pointer"
                        >
                          <option value="120000">Any budget</option>
                          <option value="45000">Under PKR 45,000</option>
                          <option value="70000">Under PKR 70,000</option>
                          <option value="95000">Under PKR 95,000</option>
                        </select>
                      </div>
                      <button
                        onClick={() => setActiveTab('properties')}
                        className="bg-sky-600 hover:bg-sky-850 text-white font-black text-xs uppercase tracking-wider rounded-xl md:rounded-full px-8 py-3.5 flex items-center justify-center gap-1.5 transition shadow-md cursor-pointer"
                      >
                        <Search size={14} />
                        <span>Search</span>
                      </button>
                    </div>
                  </div>
                </section>

                {/* Grid popular destinations */}
                <section className="max-w-7xl mx-auto px-6">
                  <div className="text-center space-y-2 mb-12">
                    <span className="text-sky-600 font-black uppercase tracking-widest text-[11px]">Explore Locations</span>
                    <h3 className="text-3xl font-extrabold text-slate-900 tracking-tight">Our Exclusive Beach Belts</h3>
                    <p className="text-slate-500 font-semibold text-sm max-w-lg mx-auto">Select from Karachi’s four premier coastline retreat neighborhoods.</p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                    {[
                      { name: 'Hawksbay Beach', img: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=600&q=80', tag: 'Sandy shoreline' },
                      { name: 'Sandspit Beach', img: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=600&q=80', tag: 'Quiet walks' },
                      { name: 'Turtle Beach', img: 'https://images.unsplash.com/photo-1437622368342-7a3d73a34c8f?auto=format&fit=crop&w=600&q=80', tag: 'Turtle Spotting' },
                      { name: 'French Beach', img: 'https://images.unsplash.com/photo-1507089947368-19c1da9775ae?auto=format&fit=crop&w=600&q=80', tag: 'Exclusive rocky cove' }
                    ].map((dest, idx) => (
                      <div 
                        key={idx}
                        onClick={() => {
                          setSearchLocation(dest.name.split(' ')[0]);
                          setActiveTab('properties');
                        }}
                        className="relative rounded-3xl overflow-hidden h-64 shadow-sm hover:shadow-xl transition group cursor-pointer border border-slate-100"
                      >
                        <img src={dest.img} alt={dest.name} className="w-full h-full object-cover group-hover:scale-105 transition duration-500" />
                        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/20 to-transparent"></div>
                        <div className="absolute bottom-5 left-5 text-white">
                          <h4 className="font-extrabold text-base tracking-tight">{dest.name}</h4>
                          <span className="text-[10px] text-sky-300 font-bold tracking-widest uppercase mt-1 block">{dest.tag}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </section>

                {/* Featured Beach Houses */}
                <section className="max-w-7xl mx-auto px-6">
                  <div className="flex justify-between items-end mb-10">
                    <div>
                      <span className="text-sky-600 font-black uppercase tracking-widest text-[11px]">Handpicked Selection</span>
                      <h3 className="text-3xl font-extrabold text-slate-900 tracking-tight">Featured Beach Houses</h3>
                    </div>
                    <button
                      onClick={() => setActiveTab('properties')}
                      className="text-sky-600 hover:text-sky-850 font-black text-xs uppercase tracking-wider flex items-center gap-1 cursor-pointer"
                    >
                      <span>Explore All listings</span>
                      <span>→</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {featuredProperties.map(prop => (
                      <PropertyCard
                        key={prop.id}
                        property={prop}
                        viewMode="grid"
                        onSelect={(id) => setSelectedPropertyId(id)}
                        isFavorite={favorites.includes(prop.id)}
                        onToggleFavorite={(id, e) => handleToggleFavorite(id, e)}
                      />
                    ))}
                  </div>
                </section>

                {/* About Hawksbay Beach House Section */}
                <section className="bg-white py-16 border-t border-b border-slate-100">
                  <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                    <div className="space-y-6">
                      <span className="bg-sky-50 text-sky-700 text-[10px] font-black uppercase tracking-widest px-3.5 py-1.5 rounded-xl border border-sky-100">
                        ABOUT OUR PORTAL
                      </span>
                      <h3 className="text-3xl lg:text-4xl font-extrabold tracking-tight text-slate-900 leading-tight">
                        Experience Premium Coastal Hospitality
                      </h3>
                      <p className="text-slate-500 font-medium text-sm leading-relaxed">
                        Hawksbay Beach House is Karachi’s elite booking agent, managing private retreats and beach huts. Every single cottage, cabin, and mansion is thoroughly inspected for security details, heavy-duty generators, sweet tap water availability, and clean swimming pools.
                      </p>
                      
                      <div className="grid grid-cols-2 gap-6 text-sm font-semibold text-slate-700 pt-2">
                        <div className="flex items-center gap-2.5">
                          <CheckCircle size={18} className="text-emerald-500 shrink-0" />
                          <span>24/7 Security Guard Staff</span>
                        </div>
                        <div className="flex items-center gap-2.5">
                          <CheckCircle size={18} className="text-emerald-500 shrink-0" />
                          <span>Sweet tap water supply</span>
                        </div>
                        <div className="flex items-center gap-2.5">
                          <CheckCircle size={18} className="text-emerald-500 shrink-0" />
                          <span>Heated / Freshwater Pools</span>
                        </div>
                        <div className="flex items-center gap-2.5">
                          <CheckCircle size={18} className="text-emerald-500 shrink-0" />
                          <span>Heavy duty power backup</span>
                        </div>
                      </div>
                    </div>

                    <div className="rounded-3xl overflow-hidden h-[380px] shadow-lg border border-slate-100 relative">
                      <img
                        src="https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=1200&q=80"
                        alt="Resort Pool"
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute bottom-6 right-6 bg-white p-4.5 rounded-2xl shadow-md border border-slate-100 flex items-center gap-3">
                        <span className="text-3xl font-black text-sky-600 leading-none">20+</span>
                        <span className="text-[10px] text-slate-400 font-black uppercase tracking-wider block">Inspected<br />villas</span>
                      </div>
                    </div>
                  </div>
                </section>

                {/* Popular Testimonial Carousel simulation */}
                <section className="max-w-7xl mx-auto px-6">
                  <div className="text-center mb-12">
                    <span className="text-sky-600 font-black uppercase tracking-widest text-[11px]">Happy Guests</span>
                    <h3 className="text-3xl font-extrabold text-slate-900 tracking-tight">Our Client Feedbacks</h3>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {[
                      { name: 'Kamran Shah', role: 'Corporate CEO', quote: 'The Azure Sands Retreat has standard high facilities. The generator backed up the pool and ACs flawlessly.' },
                      { name: 'Sana Ahmed', role: 'Family Vacationer', quote: 'Sandspit is beautiful, very tidy sandy shore. Kids loved the swings and lawn area. Safe, clean, and amazing security!' },
                      { name: 'Waqas Bhatti', role: 'snorkeling lover', quote: 'Handcrafted stone cabin on French Beach is unmatched. Crystal clear rock pools. High-speed Starlink WiFi was extremely fast!' }
                    ].map((t, idx) => (
                      <div key={idx} className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm flex flex-col justify-between h-56">
                        <p className="text-slate-600 text-xs font-semibold leading-relaxed italic">" {t.quote} "</p>
                        <div className="flex items-center gap-3.5 border-t border-slate-50 pt-4 mt-4">
                          <div className="bg-sky-100 text-sky-700 w-10 h-10 rounded-full flex items-center justify-center font-bold">
                            {t.name.charAt(0)}
                          </div>
                          <div>
                            <h4 className="font-extrabold text-xs text-slate-900 tracking-tight">{t.name}</h4>
                            <span className="text-[10px] text-slate-400 font-bold block mt-0.5">{t.role}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </section>

                {/* Stateful FAQ Accordion Section */}
                <section className="bg-slate-100/50 py-16 border-t border-b border-slate-100">
                  <div className="max-w-4xl mx-auto px-6">
                    <div className="text-center mb-12 space-y-2">
                      <span className="text-sky-600 font-black uppercase tracking-widest text-[11px]">Frequently Asked Questions</span>
                      <h3 className="text-3xl font-extrabold text-slate-900 tracking-tight">Booking Information & Guidelines</h3>
                      <p className="text-slate-500 font-semibold text-sm max-w-md mx-auto">Got questions about your upcoming beach house vacation? Find answers below.</p>
                    </div>

                    <div className="space-y-4">
                      {[
                        {
                          q: 'How do I book a beach house rental?',
                          a: 'Simply select your desired property and fill out the Booking Request form with your details. Our customer relations officer will immediately connect with you on WhatsApp to confirm the availability, share precise pricing, and provide our official bank deposit details to secure your reservation.'
                        },
                        {
                          q: 'What are the standard check-in and check-out times?',
                          a: 'Standard check-in time is at 12:00 PM (Noon), and check-out is at 10:00 AM the following morning. This allows our dedicated facilities crew to thoroughly clean, sanitize, and prepare the beach compound for the next incoming guests.'
                        },
                        {
                          q: 'Are standby electricity generators included in the rental?',
                          a: 'Yes, all premium rentals featured on Hawksbay Beach House are equipped with high-capacity automatic backup generators to run all heavy air conditioners and pool filtration units smoothly during any local outage.'
                        },
                        {
                          q: 'Do the properties have fresh sweet water supply?',
                          a: 'Absolutely. We ensure that fresh water tankers replenish the sweet water storage tanks at the property prior to your check-in, providing optimal clean water for kitchen utilities, washrooms, and showers.'
                        },
                        {
                          q: 'Is swimming in the sea safe at Karachi beaches?',
                          a: 'Swimming safety varies by season. During winter (October to March), waves are gentle, but safety caution is always advised. During summer monsoon months (June to September), swimming in the sea is strictly prohibited. However, you can enjoy unlimited, safe swimming inside our properties private freshwater pools year-round!'
                        }
                      ].map((faq, idx) => {
                        const isOpen = openFaqIndex === idx;
                        return (
                          <div 
                            key={idx} 
                            className="bg-white rounded-2xl border border-slate-150 shadow-sm overflow-hidden transition-all duration-300"
                          >
                            <button
                              onClick={() => setOpenFaqIndex(isOpen ? null : idx)}
                              className="w-full p-6 text-left flex justify-between items-center font-extrabold text-slate-900 hover:bg-slate-50/50 gap-4 cursor-pointer transition"
                            >
                              <span className="text-sm md:text-base">{faq.q}</span>
                              <span className="text-sky-600">
                                {isOpen ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
                              </span>
                            </button>
                            {isOpen && (
                              <div className="p-6 pt-0 border-t border-slate-50 text-slate-500 font-medium text-xs md:text-sm leading-relaxed whitespace-pre-line bg-slate-50/30">
                                {faq.a}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </section>

                {/* Latest Travel Guides */}
                <section className="max-w-7xl mx-auto px-6">
                  <div className="flex justify-between items-end mb-10">
                    <div>
                      <span className="text-sky-600 font-black uppercase tracking-widest text-[11px]">Beach Wisdom</span>
                      <h3 className="text-3xl font-extrabold text-slate-900 tracking-tight">Latest Guides & Travel Blogs</h3>
                    </div>
                    <button
                      onClick={() => setActiveTab('blogs')}
                      className="text-sky-600 hover:text-sky-850 font-black text-xs uppercase tracking-wider flex items-center gap-1 cursor-pointer"
                    >
                      <span>Read All Blogs</span>
                      <span>→</span>
                    </button>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {blogs.slice(0, 3).map(blog => (
                      <div 
                        key={blog.id} 
                        onClick={() => setSelectedBlogId(blog.id)}
                        className="bg-white rounded-3xl overflow-hidden border border-slate-100 shadow-sm hover:shadow-lg transition-all group cursor-pointer flex flex-col justify-between h-[420px]"
                      >
                        <div className="relative h-48 overflow-hidden">
                          <img src={blog.image} alt={blog.title} className="w-full h-full object-cover group-hover:scale-105 transition duration-500" />
                          <span className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm text-[10px] font-black uppercase tracking-widest text-sky-900 px-3 py-1 rounded-full shadow-sm">
                            {blog.category}
                          </span>
                        </div>
                        <div className="p-6 flex-1 flex flex-col justify-between">
                          <div className="space-y-2">
                            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{blog.date} • {blog.readTime}</span>
                            <h4 className="font-bold text-slate-900 group-hover:text-sky-600 transition duration-200 text-base line-clamp-2">
                              {blog.title}
                            </h4>
                            <p className="text-slate-500 text-xs font-semibold leading-relaxed line-clamp-2">
                              {blog.excerpt}
                            </p>
                          </div>
                          <span className="text-sky-600 font-extrabold text-xs uppercase tracking-widest block pt-4">Read Article →</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </section>
              </div>
            )}

            {/* B. PROPERTIES LISTINGS TAB */}
            {activeTab === 'properties' && (
              <div className="max-w-7xl mx-auto px-6 py-8">
                {/* Search Header Row */}
                <div className="bg-white border border-slate-100 p-6 rounded-3xl shadow-sm mb-8 flex flex-col lg:flex-row gap-4 justify-between items-center">
                  <div>
                    <h2 className="text-2xl font-black text-slate-900 tracking-tight">Luxury Beach Huts & Houses</h2>
                    <span className="text-xs text-slate-400 font-semibold">{filteredProperties.length} properties matching criteria</span>
                  </div>

                  {/* Grid / List layout togglers */}
                  <div className="flex gap-2.5">
                    <button
                      onClick={() => setViewMode('grid')}
                      className={`p-2.5 rounded-xl border transition ${
                        viewMode === 'grid' ? 'bg-sky-50 border-sky-200 text-sky-700' : 'bg-white border-slate-100 text-slate-400 hover:text-slate-600'
                      }`}
                    >
                      <Grid size={16} />
                    </button>
                    <button
                      onClick={() => setViewMode('list')}
                      className={`p-2.5 rounded-xl border transition ${
                        viewMode === 'list' ? 'bg-sky-50 border-sky-200 text-sky-700' : 'bg-white border-slate-100 text-slate-400 hover:text-slate-600'
                      }`}
                    >
                      <List size={16} />
                    </button>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
                  
                  {/* Left Side: Advanced Filters Bar */}
                  <div className="space-y-6">
                    <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm space-y-6">
                      <h3 className="font-extrabold text-slate-900 text-base border-b border-slate-50 pb-3">Filters</h3>
                      
                      {/* Location Filter */}
                      <div className="space-y-2">
                        <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest">Select Coastline</label>
                        <select
                          value={searchLocation}
                          onChange={(e) => setSearchLocation(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-xs font-semibold focus:border-sky-500 focus:ring-1 focus:ring-sky-500"
                        >
                          <option value="">All Karachi Beaches</option>
                          <option value="Hawksbay">Hawksbay Beach</option>
                          <option value="Sandspit">Sandspit Beach</option>
                          <option value="Turtle">Turtle Beach</option>
                          <option value="French">French Beach</option>
                        </select>
                      </div>

                      {/* Price Range Filter */}
                      <div className="space-y-2.5">
                        <div className="flex justify-between text-xs font-bold text-slate-500">
                          <span className="uppercase tracking-widest">Max Budget</span>
                          <span className="text-sky-600">PKR {searchPriceMax.toLocaleString()}</span>
                        </div>
                        <input
                          type="range"
                          min={30000}
                          max={120000}
                          step={5000}
                          value={searchPriceMax}
                          onChange={(e) => setSearchPriceMax(Number(e.target.value))}
                          className="w-full h-1.5 bg-slate-100 rounded-lg appearance-none cursor-pointer accent-sky-600"
                        />
                      </div>

                      {/* Bedrooms Filter */}
                      <div className="space-y-2">
                        <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest">Minimum Bedrooms</label>
                        <select
                          value={searchBedrooms}
                          onChange={(e) => setSearchBedrooms(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-xs font-semibold"
                        >
                          <option value="any">Any Bedrooms</option>
                          <option value="2">2+ Bedrooms</option>
                          <option value="3">3+ Bedrooms</option>
                          <option value="4">4+ Bedrooms</option>
                          <option value="5">5+ Bedrooms</option>
                        </select>
                      </div>

                      {/* Capacity Filter */}
                      <div className="space-y-2">
                        <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest">Minimum Guest Capacity</label>
                        <select
                          value={searchCapacity}
                          onChange={(e) => setSearchCapacity(e.target.value)}
                          className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-xs font-semibold"
                        >
                          <option value="any">Any Capacity</option>
                          <option value="8">8+ Guests</option>
                          <option value="15">15+ Guests</option>
                          <option value="25">25+ Guests</option>
                          <option value="35">35+ Guests</option>
                        </select>
                      </div>

                      {/* Amenities Checkbox list */}
                      <div className="space-y-3.5 border-t border-slate-50 pt-5">
                        <label className="flex items-center gap-2 text-xs font-bold text-slate-600 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={filterPool}
                            onChange={(e) => setFilterPool(e.target.checked)}
                            className="rounded border-slate-300 text-sky-600 focus:ring-sky-500"
                          />
                          <span>Swimming Pool</span>
                        </label>
                        <label className="flex items-center gap-2 text-xs font-bold text-slate-600 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={filterBBQ}
                            onChange={(e) => setFilterBBQ(e.target.checked)}
                            className="rounded border-slate-300 text-sky-600 focus:ring-sky-500"
                          />
                          <span>BBQ Deck / Grill Pit</span>
                        </label>
                        <label className="flex items-center gap-2 text-xs font-bold text-slate-600 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={filterBeachView}
                            onChange={(e) => setFilterBeachView(e.target.checked)}
                            className="rounded border-slate-300 text-sky-600 focus:ring-sky-500"
                          />
                          <span>Direct Sea Views</span>
                        </label>
                        <label className="flex items-center gap-2 text-xs font-bold text-slate-600 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={filterFamily}
                            onChange={(e) => setFilterFamily(e.target.checked)}
                            className="rounded border-slate-300 text-sky-600 focus:ring-sky-500"
                          />
                          <span>Family Safe Compound</span>
                        </label>
                      </div>
                    </div>
                  </div>

                  {/* Right Side: Properties grid lists */}
                  <div className="lg:col-span-3">
                    {filteredProperties.length > 0 ? (
                      <div className={viewMode === 'grid' ? 'grid grid-cols-1 md:grid-cols-2 gap-8' : 'flex flex-col gap-8'}>
                        {filteredProperties.map(prop => (
                          <PropertyCard
                            key={prop.id}
                            property={prop}
                            viewMode={viewMode}
                            onSelect={(id) => setSelectedPropertyId(id)}
                            isFavorite={favorites.includes(prop.id)}
                            onToggleFavorite={(id, e) => handleToggleFavorite(id, e)}
                          />
                        ))}
                      </div>
                    ) : (
                      <div className="bg-white rounded-3xl border border-dashed border-slate-200 p-16 text-center max-w-xl mx-auto space-y-4">
                        <Info size={36} className="text-slate-400 mx-auto" />
                        <h4 className="font-extrabold text-slate-900 text-lg">No properties found</h4>
                        <p className="text-slate-500 text-xs font-semibold leading-relaxed">
                          We couldn't find any beach houses matching your selected filters. Try broadening your budget range or choosing a different coastline.
                        </p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* C. TRAVEL BLOGS TAB */}
            {activeTab === 'blogs' && (
              <div className="max-w-7xl mx-auto px-6 py-8 space-y-12 animate-fade-in">
                <div className="text-center space-y-2">
                  <span className="text-sky-600 font-black uppercase tracking-widest text-[11px]">Beach Wisdom</span>
                  <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">Karachi Beach Guides & Travel Blogs</h2>
                  <p className="text-slate-500 font-semibold text-sm max-w-lg mx-auto">Discover local turtle habitats, BBQ traditions, snorkeling channels, and weekend safety tips.</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                  {blogs.map(blog => (
                    <div 
                      key={blog.id} 
                      onClick={() => setSelectedBlogId(blog.id)}
                      className="bg-white rounded-3xl overflow-hidden border border-slate-100 shadow-sm hover:shadow-lg transition-all group cursor-pointer flex flex-col justify-between h-[420px]"
                    >
                      <div className="relative h-48 overflow-hidden">
                        <img src={blog.image} alt={blog.title} className="w-full h-full object-cover group-hover:scale-105 transition duration-500" />
                        <span className="absolute top-4 left-4 bg-white/90 backdrop-blur-sm text-[10px] font-black uppercase tracking-widest text-sky-900 px-3 py-1 rounded-full shadow-sm">
                          {blog.category}
                        </span>
                      </div>
                      <div className="p-6 flex-1 flex flex-col justify-between">
                        <div className="space-y-2">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">{blog.date} • {blog.readTime}</span>
                          <h4 className="font-bold text-slate-900 group-hover:text-sky-600 transition duration-200 text-base line-clamp-2">
                            {blog.title}
                          </h4>
                          <p className="text-slate-500 text-xs font-semibold leading-relaxed line-clamp-2">
                            {blog.excerpt}
                          </p>
                        </div>
                        <span className="text-sky-600 font-extrabold text-xs uppercase tracking-widest block pt-4">Read Article →</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* D. CONTACT TAB */}
            {activeTab === 'contact' && (
              <div className="max-w-7xl mx-auto px-6 py-8 space-y-12">
                <div className="text-center space-y-2">
                  <span className="text-sky-600 font-black uppercase tracking-widest text-[11px]">Get in Touch</span>
                  <h2 className="text-3xl font-extrabold text-slate-900 tracking-tight">Contact Hawksbay Beach House</h2>
                  <p className="text-slate-500 font-semibold text-sm max-w-lg mx-auto">Reach out to our reservation experts directly or send a custom inquiry.</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                  {/* Left Side: Contact Form */}
                  <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm space-y-6">
                    <h3 className="font-extrabold text-slate-900 text-lg">Send Inquiry Message</h3>
                    
                    {contactSuccess ? (
                      <div className="bg-emerald-50 border border-emerald-100 text-emerald-800 p-6 rounded-2xl space-y-2 font-semibold">
                        <CheckCircle size={24} className="text-emerald-600" />
                        <h4 className="font-extrabold text-base">Inquiry Submitted!</h4>
                        <p className="text-xs leading-relaxed font-semibold text-emerald-700">
                          Thank you for contacting Hawksbay Beach House. Our operations team has received your details and will WhatsApp you shortly with booking rates.
                        </p>
                        <button
                          onClick={() => setContactSuccess(false)}
                          className="text-xs font-black uppercase text-emerald-800 hover:underline pt-2 cursor-pointer"
                        >
                          Submit another message
                        </button>
                      </div>
                    ) : (
                      <form onSubmit={handleContactSubmit} className="space-y-4">
                        <div>
                          <label className="block text-xs font-bold text-slate-500 mb-1">YOUR NAME</label>
                          <input
                            type="text"
                            required
                            value={contactName}
                            onChange={(e) => setContactName(e.target.value)}
                            placeholder="Zeeshan Sheikh"
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:border-sky-500 focus:ring-1 focus:ring-sky-500"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-bold text-slate-500 mb-1">PHONE / WHATSAPP NUMBER</label>
                          <input
                            type="text"
                            required
                            value={contactPhone}
                            onChange={(e) => setContactPhone(e.target.value)}
                            placeholder="+92 300 1234567"
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:border-sky-500 focus:ring-1 focus:ring-sky-500"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-bold text-slate-500 mb-1">MESSAGE</label>
                          <textarea
                            rows={4}
                            required
                            value={contactMsg}
                            onChange={(e) => setContactMsg(e.target.value)}
                            placeholder="Describe your requested dates, headcount, and pool specifications..."
                            className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:border-sky-500 focus:ring-1 focus:ring-sky-500"
                          ></textarea>
                        </div>
                        <button
                          type="submit"
                          className="bg-sky-600 hover:bg-sky-850 text-white font-extrabold text-xs uppercase tracking-wider py-4 rounded-2xl w-full shadow-md cursor-pointer flex items-center justify-center gap-1.5 transition"
                        >
                          <Send size={14} />
                          <span>Submit Message</span>
                        </button>
                      </form>
                    )}
                  </div>

                  {/* Right Side: Map & WhatsApp */}
                  <div className="space-y-8 flex flex-col justify-between">
                    <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm space-y-6">
                      <h3 className="font-extrabold text-slate-900 text-lg">Direct WhatsApp Hotlines</h3>
                      <p className="text-slate-500 text-xs font-medium leading-relaxed">
                        Skip forms completely! Chat with our reservation head instantly to get immediate custom pricing, group discounts, and catering packages.
                      </p>
                      
                      {/* WhatsApp Button */}
                      <a
                        href={`https://wa.me/${settings.whatsapp}?text=Hi%20Hawksbay%20Beach%20House%20Rentals,%20I%20would%20like%20to%20inquire%20about%20booking%2520details.`}
                        target="_blank"
                        rel="noreferrer"
                        className="bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs uppercase tracking-wider py-4 px-6 rounded-2xl shadow-md cursor-pointer flex items-center justify-center gap-2 transition"
                      >
                        <MessageSquare size={16} />
                        <span>Chat Instantly on WhatsApp</span>
                      </a>
                    </div>

                    {/* Google Map Simulation iframe */}
                    <div className="rounded-3xl overflow-hidden h-[250px] border border-slate-100 relative shadow-sm">
                      <iframe
                        title="Hawksbay Beach Location"
                        src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14488.948255938833!2d66.85244585!3d24.8459477!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3eb311b51e9b2511%3A0xe5c3c0bc52df713f!2sHawke's%20Bay%20Beach!5e0!3m2!1sen!2spk!4v1700000000000!5m2!1sen!2spk"
                        className="w-full h-full border-none"
                        allowFullScreen={false}
                        loading="lazy"
                      ></iframe>
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* E. ADMIN PANEL TAB */}
            {activeTab === 'admin' && (
              <AdminPanel
                properties={properties}
                bookings={bookings}
                reviews={reviews}
                blogs={blogs}
                settings={settings}
                currentRole={currentRole as 'Moderator' | 'Admin'}
                onUpdateBookingStatus={handleUpdateBookingStatus}
                onUpdatePaymentStatus={handleUpdatePaymentStatus}
                onApproveReview={handleApproveReview}
                onDeleteReview={handleDeleteReview}
                onAddProperty={handleAddProperty}
                onDeleteProperty={handleDeleteProperty}
                onAddBlog={handleAddBlog}
                onDeleteBlog={handleDeleteBlog}
                onUpdateSettings={(newSet) => setSettings(newSet)}
              />
            )}

            {/* G. USER PROFILE TAB */}
            {activeTab === 'profile' && (
              <div className="max-w-7xl mx-auto px-6 py-8 space-y-10">
                <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm flex items-center justify-between flex-wrap gap-4">
                  <div className="flex items-center gap-5">
                    <div className="bg-sky-100 text-sky-700 w-16 h-16 rounded-full flex items-center justify-center font-black text-2xl">
                      {currentUser?.name.charAt(0)}
                    </div>
                    <div>
                      <h2 className="text-2xl font-black text-slate-900">{currentUser?.name}</h2>
                      <span className="text-xs font-semibold text-slate-400 block mt-0.5">{currentUser?.email}</span>
                      <span className="bg-sky-50 text-sky-800 text-[10px] font-bold px-2.5 py-1 rounded-md mt-2 inline-block">
                        Access Level: {currentRole}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Grid favorite listings and booking history */}
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
                  {/* Left (2 Columns) Booking History */}
                  <div className="lg:col-span-2 space-y-6">
                    <h3 className="font-extrabold text-slate-900 text-lg">My Booking History ({bookings.filter(b => b.guestEmail === currentUser?.email).length})</h3>
                    
                    {bookings.filter(b => b.guestEmail === currentUser?.email).length > 0 ? (
                      <div className="space-y-4">
                        {bookings
                          .filter(b => b.guestEmail === currentUser?.email)
                          .map(booking => (
                            <div key={booking.id} className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                              <div className="space-y-2">
                                <span className="bg-sky-50 text-sky-700 text-[9px] font-black uppercase tracking-wider px-2.5 py-1 rounded-md">
                                  {booking.id}
                                </span>
                                <h4 className="font-extrabold text-slate-900 text-sm leading-tight">{booking.propertyName}</h4>
                                <div className="text-xs text-slate-500 font-semibold flex flex-wrap gap-3">
                                  <span>Stay: {booking.checkIn} to {booking.checkOut}</span>
                                  <span>•</span>
                                  <span>Capacity: {booking.guests} Guests</span>
                                </div>
                              </div>
                              <div className="flex items-center gap-4 self-stretch sm:self-auto justify-between sm:justify-end">
                                <div>
                                  <span className="text-base font-black text-slate-900 block">PKR {booking.totalPrice.toLocaleString()}</span>
                                  <span className="text-[10px] font-bold uppercase tracking-wider block mt-0.5 text-slate-400">Total Price</span>
                                </div>
                                <div className="flex flex-col items-end gap-1.5">
                                  <span className={`inline-block px-2.5 py-1 rounded-full text-[9px] font-black uppercase tracking-wider ${
                                    booking.status === 'Approved' ? 'bg-emerald-50 text-emerald-700' :
                                    booking.status === 'Pending' ? 'bg-sky-50 text-sky-700 animate-pulse' :
                                    'bg-rose-50 text-rose-600'
                                  }`}>
                                    {booking.status}
                                  </span>
                                  {booking.status === 'Approved' && (
                                    <button
                                      onClick={() => handleDownloadPDF(booking)}
                                      className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-sky-50 hover:bg-sky-100 text-sky-700 text-[10px] font-extrabold uppercase tracking-wider transition cursor-pointer mt-0.5 border border-sky-100/50"
                                      title="Download PDF Booking Summary"
                                    >
                                      <FileDown size={12} className="shrink-0" />
                                      <span>Download PDF</span>
                                    </button>
                                  )}
                                  <button
                                    onClick={() => handleCancelBooking(booking.id)}
                                    className="text-[10px] font-black text-rose-500 uppercase hover:underline cursor-pointer"
                                  >
                                    Cancel Request
                                  </button>
                                </div>
                              </div>
                            </div>
                          ))}
                      </div>
                    ) : (
                      <div className="bg-white p-8 rounded-3xl border border-dashed border-slate-200 text-center">
                        <p className="text-slate-500 text-sm">You haven't requested any beach house bookings yet.</p>
                      </div>
                    )}
                  </div>

                  {/* Right (1 Column) Saved Favorites */}
                  <div className="space-y-6">
                    <h3 className="font-extrabold text-slate-900 text-lg">My Favorites ({favorites.length})</h3>
                    {favorites.length > 0 ? (
                      <div className="space-y-4">
                        {properties
                          .filter(p => favorites.includes(p.id))
                          .map(prop => (
                            <div 
                              key={prop.id}
                              onClick={() => setSelectedPropertyId(prop.id)}
                              className="bg-white p-4 rounded-3xl border border-slate-100 shadow-sm flex items-center gap-3.5 hover:border-sky-200 cursor-pointer transition group"
                            >
                              <img src={prop.images[0]} alt={prop.title} className="w-16 h-16 rounded-2xl object-cover shrink-0" />
                              <div className="min-w-0">
                                <h4 className="font-extrabold text-xs text-slate-900 group-hover:text-sky-600 transition truncate">{prop.title}</h4>
                                <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mt-1 block">{prop.location}</span>
                                <span className="text-[11px] font-black text-slate-900 block mt-1">PKR {prop.pricePerNight.toLocaleString()} / night</span>
                              </div>
                            </div>
                          ))}
                      </div>
                    ) : (
                      <div className="bg-white p-6 rounded-3xl border border-dashed border-slate-200 text-center">
                        <p className="text-slate-500 text-xs">No favorites added yet.</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            )}
          </>
        )}
      </main>

      {/* Global Theme Footer */}
      <Footer 
        onTabChange={(tab) => {
          setActiveTab(tab);
          setSelectedPropertyId(null);
          setSelectedBlogId(null);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }} 
        onOpenPrivacyModal={() => setShowPrivacyModal(true)}
        onOpenTermsModal={() => setShowTermsModal(true)}
      />

      {/* Portal Login Modal */}
      {showLoginModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-6 animate-fade-in">
          <div className="bg-white max-w-md w-full p-8 rounded-3xl border border-slate-100 shadow-2xl relative space-y-6">
            <button
              onClick={() => {
                setShowLoginModal(false);
                setAuthError(null);
              }}
              className="absolute top-5 right-5 bg-slate-100 hover:bg-slate-200 text-slate-500 p-1.5 rounded-full transition cursor-pointer"
            >
              <X size={16} />
            </button>

            <div className="text-center space-y-1.5">
              <div className="w-12 h-12 bg-sky-50 text-sky-600 rounded-full flex items-center justify-center mx-auto mb-1">
                <Lock size={20} />
              </div>
              <h3 className="text-xl font-black text-slate-900 tracking-tight">Portal Authentication</h3>
              <p className="text-slate-400 text-xs font-semibold leading-relaxed">
                Enter your authorized supervisor or partner credentials to access secure management dashboards.
              </p>
            </div>

            {/* Secure login credentials helper */}
            <div className="bg-slate-50 border border-slate-100 p-4.5 rounded-2xl text-xs space-y-2">
              <span className="font-black text-slate-800 uppercase tracking-widest text-[9px] block mb-1">Authorized Supervisor Access:</span>
              <p className="text-slate-500 font-medium leading-relaxed text-[10px] mb-2">
                For verified administrative evaluation, authenticate using the authorized accounts below:
              </p>
              <div className="flex flex-col gap-1.5 font-semibold text-slate-600">
                <div className="flex justify-between border-b border-slate-100 pb-1 text-[11px]">
                  <span>Admin: <code className="text-sky-600 font-mono">admin@hawksbay.com</code></span>
                  <span>Pass: <code className="text-sky-600 font-mono">admin123</code></span>
                </div>
                <div className="flex justify-between text-[11px]">
                  <span>Moderator: <code className="text-sky-600 font-mono">mod@hawksbay.com</code></span>
                  <span>Pass: <code className="text-sky-600 font-mono">mod123</code></span>
                </div>
              </div>
            </div>

            {authError && (
              <div className="bg-rose-50 border border-rose-100 text-rose-700 px-4 py-2.5 rounded-xl text-xs font-bold text-center">
                {authError}
              </div>
            )}

            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-[10px] font-black text-slate-400 mb-1.5 uppercase tracking-widest">EMAIL ADDRESS</label>
                <input
                  type="email"
                  required
                  value={loginEmail}
                  onChange={(e) => setLoginEmail(e.target.value)}
                  placeholder="e.g. admin@hawksbay.com"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3.5 text-xs font-bold text-slate-800 focus:bg-white focus:border-sky-500 focus:ring-1 focus:ring-sky-500 outline-none"
                />
              </div>

              <div>
                <label className="block text-[10px] font-black text-slate-400 mb-1.5 uppercase tracking-widest">PASSWORD</label>
                <input
                  type="password"
                  required
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3.5 text-xs font-bold text-slate-800 focus:bg-white focus:border-sky-500 focus:ring-1 focus:ring-sky-500 outline-none"
                />
              </div>

              <button
                type="submit"
                className="w-full bg-sky-600 hover:bg-sky-750 text-white font-extrabold text-xs uppercase tracking-wider py-4 rounded-2xl shadow-md transition cursor-pointer"
              >
                Verify & Log In
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Privacy Policy Modal */}
      {showPrivacyModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-6 animate-fade-in">
          <div className="bg-white max-w-lg w-full p-8 rounded-3xl border border-slate-100 shadow-2xl relative space-y-6">
            <button
              onClick={() => setShowPrivacyModal(false)}
              className="absolute top-5 right-5 bg-slate-100 hover:bg-slate-200 text-slate-500 p-1.5 rounded-full transition cursor-pointer"
            >
              <X size={16} />
            </button>
            <div className="space-y-2">
              <h3 className="text-xl font-black text-slate-900 tracking-tight">Privacy Policy</h3>
              <p className="text-slate-400 text-xs font-semibold">Last Updated: July 2026</p>
            </div>
            <div className="text-xs text-slate-600 space-y-4 max-h-[350px] overflow-y-auto pr-2 font-medium leading-relaxed">
              <p>Welcome to Hawksbay Beach House. We value your privacy and are committed to protecting your personal information. This Privacy Policy details how we collect, use, and safe-guard your data during your bookings.</p>
              <h4 className="font-bold text-slate-900">1. Information We Collect</h4>
              <p>When you submit a booking request, we collect your name, email address, phone/WhatsApp number, and specific rental preferences. This data is exclusively used to coordinate your beachfront booking.</p>
              <h4 className="font-bold text-slate-900">2. How We Use Information</h4>
              <p>We use your contact details solely to confirm reservation availability, send booking invoices, coordinate key handover, and address emergency assistance needs during your stay.</p>
              <h4 className="font-bold text-slate-900">3. Data Retention & Sharing</h4>
              <p>We do not sell, rent, or share customer information with third parties. Your details remain stored securely in our private administrative system.</p>
              <p>For questions or requests regarding your data, please contact us at <span className="text-sky-600 font-bold">info@hawksbaybeachhouse.com</span>.</p>
            </div>
          </div>
        </div>
      )}

      {/* Terms & Conditions Modal */}
      {showTermsModal && (
        <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-sm flex items-center justify-center p-6 animate-fade-in">
          <div className="bg-white max-w-lg w-full p-8 rounded-3xl border border-slate-100 shadow-2xl relative space-y-6">
            <button
              onClick={() => setShowTermsModal(false)}
              className="absolute top-5 right-5 bg-slate-100 hover:bg-slate-200 text-slate-500 p-1.5 rounded-full transition cursor-pointer"
            >
              <X size={16} />
            </button>
            <div className="space-y-2">
              <h3 className="text-xl font-black text-slate-900 tracking-tight">Terms & Conditions</h3>
              <p className="text-slate-400 text-xs font-semibold">Last Updated: July 2026</p>
            </div>
            <div className="text-xs text-slate-650 space-y-4 max-h-[350px] overflow-y-auto pr-2 font-medium leading-relaxed">
              <p>These terms govern your booking requests and lodging at any private beach house listed on our portal.</p>
              <h4 className="font-bold text-slate-900">1. Booking Request & Payment</h4>
              <p>Submitting a request does not constitute a guaranteed reservation. Reservations are only finalized upon verification of a 50% advance deposit via bank transfer. The remaining balance must be paid prior to check-in.</p>
              <h4 className="font-bold text-slate-900">2. Guest Capacity Constraints</h4>
              <p>Each beach house listing specifies a strict maximum guest capacity. Overcrowding past the authorized count without prior written approval from management will result in immediate reservation cancellation with no refund.</p>
              <h4 className="font-bold text-slate-900">3. Safety & Sea Advisories</h4>
              <p>Guests are strictly required to adhere to all Sindh Government security directives and sea swimming ban alerts (particularly during heavy monsoon seasons). Swimming in the sea is at your own risk. Hawksbay Beach House is not liable for personal safety incidents.</p>
              <h4 className="font-bold text-slate-900">4. Damages & Maintenance</h4>
              <p>Any damage to the property, generators, private swimming pools, or furniture during your stay will be charged directly to the booking guest.</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
