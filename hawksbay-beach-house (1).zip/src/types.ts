/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Property {
  id: string;
  title: string;
  description: string;
  pricePerNight: number;
  location: string;
  bedrooms: number;
  bathrooms: number;
  guestCapacity: number;
  hasPool: boolean;
  hasBBQ: boolean;
  hasBeachView: boolean;
  isFamilyFriendly: boolean;
  images: string[];
  amenities: string[];
  houseRules: string[];
  featured: boolean;
}

export interface Booking {
  id: string;
  propertyId: string;
  propertyName: string;
  checkIn: string;
  checkOut: string;
  guests: number;
  totalPrice: number;
  guestName: string;
  guestEmail: string;
  guestPhone: string;
  status: 'Pending' | 'Approved' | 'Rejected' | 'Completed';
  paymentStatus: 'Pending' | 'Partially Paid' | 'Paid' | 'Refunded';
  createdAt: string;
}

export interface Review {
  id: string;
  propertyId: string;
  propertyName: string;
  authorName: string;
  rating: number;
  comment: string;
  approved: boolean;
  createdAt: string;
}

export interface Blog {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  category: string;
  tags: string[];
  author: string;
  readTime: string;
  date: string;
  image: string;
}

export interface User {
  id: string;
  email: string;
  name: string;
  role: 'User' | 'Moderator' | 'Admin';
}

export interface WebsiteSettings {
  siteName: string;
  phone: string;
  whatsapp: string;
  email: string;
  address: string;
  headerText: string;
  footerText: string;
}
