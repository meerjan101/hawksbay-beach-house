/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Review } from '../types';

export const INITIAL_REVIEWS: Review[] = [
  {
    id: 'rev-01',
    propertyId: 'hb-01',
    propertyName: 'The Azure Sands Retreat',
    authorName: 'Kamran Shah',
    rating: 5,
    comment: 'Superb! The infinity pool was clean and the standby generator kept the ACs running without a single hiccup. Our corporate team of 20 had an amazing time.',
    approved: true,
    createdAt: '2026-06-10'
  },
  {
    id: 'rev-02',
    propertyId: 'hb-01',
    propertyName: 'The Azure Sands Retreat',
    authorName: 'Dr. Yasmin Malik',
    rating: 5,
    comment: 'Amazing front view! Excellent family atmosphere. The kids loved the pool, and the kitchen was fully equipped. Host was very professional.',
    approved: true,
    createdAt: '2026-06-12'
  },
  {
    id: 'rev-03',
    propertyId: 'hb-02',
    propertyName: 'La Serena Cove',
    authorName: 'Farhan Zaidi',
    rating: 4,
    comment: 'Very serene place. Sandspit is less crowded than Hawksbay and has a much smoother sandy walk. The green lawn was very well kept.',
    approved: true,
    createdAt: '2026-06-14'
  },
  {
    id: 'rev-04',
    propertyId: 'hb-03',
    propertyName: 'Turtle Beach Royal Pavilion',
    authorName: 'Shumaila Imran',
    rating: 5,
    comment: 'Outstanding! We spotted two green turtles coming ashore at night. An unforgettable experience. The villa is majestic, clean and extremely safe.',
    approved: true,
    createdAt: '2026-06-15'
  },
  {
    id: 'rev-05',
    propertyId: 'hb-05',
    propertyName: 'Karachi Beach Crest Estate',
    authorName: 'Nabeel Siddiqui',
    rating: 5,
    comment: 'The glass lounge facing the Arabian Sea is spectacular. We booked it for a birthday celebration. Truly luxury standards right here in Karachi.',
    approved: true,
    createdAt: '2026-06-18'
  },
  {
    id: 'rev-06',
    propertyId: 'hb-06',
    propertyName: 'Ocean Breeze Sanctuary',
    authorName: 'Amna Ghafoor',
    rating: 4,
    comment: 'Perfect cozy cottage. Patios and hammocks are excellent for reading while listening to waves. Very neat washrooms.',
    approved: true,
    createdAt: '2026-06-20'
  },
  {
    id: 'rev-07',
    propertyId: 'hb-07',
    propertyName: 'The Palms Mansion',
    authorName: 'Zubair Sheikh',
    rating: 5,
    comment: 'Massive luxury pool and lovely palm decorations. The staff was incredibly helpful with setting up our barbeque grill. 10/10.',
    approved: true,
    createdAt: '2026-06-22'
  },
  {
    id: 'rev-08',
    propertyId: 'hb-08',
    propertyName: 'Coral Beachfront Cabin',
    authorName: 'Khurram Lodhi',
    rating: 4,
    comment: 'Nice budget-friendly beach cabin on Sandspit. Beds were comfortable and security guard was alert the entire night.',
    approved: true,
    createdAt: '2026-06-25'
  },
  {
    id: 'rev-09',
    propertyId: 'hb-09',
    propertyName: 'The Golden Crest Villa',
    authorName: 'Sabeen Jafri',
    rating: 4,
    comment: 'Private indoor plunge pool is a brilliant feature for women privacy. High security boundary walls made us feel completely secure.',
    approved: true,
    createdAt: '2026-06-26'
  },
  {
    id: 'rev-10',
    propertyId: 'hb-10',
    propertyName: 'Solitude Beach Estate',
    authorName: 'Aamir Memon',
    rating: 5,
    comment: 'Exclusive French Beach experience. The rocky beach was crystal clear, we did some snorkeling and saw colorful fish. Perfect high-end vacation.',
    approved: true,
    createdAt: '2026-06-27'
  },
  {
    id: 'rev-11',
    propertyId: 'hb-12',
    propertyName: 'The Sandspit Oasis',
    authorName: 'Ayesha Riaz',
    rating: 5,
    comment: 'The swimming pool was sparkling clean and fresh water supply was abundant. Highly recommended for families.',
    approved: true,
    createdAt: '2026-06-28'
  },
  {
    id: 'rev-12',
    propertyId: 'hb-15',
    propertyName: 'Blue Wave Horizon Club',
    authorName: 'Hamid Butt',
    rating: 5,
    comment: 'Excellent catering support. We hosted our annual team summit here with 35 employees. Everyone loved the pool, the sound system, and the sunset.',
    approved: true,
    createdAt: '2026-06-29'
  },
  {
    id: 'rev-13',
    propertyId: 'hb-18',
    propertyName: 'The Pebble Cove French Beach',
    authorName: 'Waqas Bhatti',
    rating: 5,
    comment: 'Handcrafted stone look is gorgeous. Perfect ocean breeze, high end interior and complete peace of mind. Truly a premium sanctuary.',
    approved: true,
    createdAt: '2026-06-30'
  },
  {
    id: 'rev-14',
    propertyId: 'hb-20',
    propertyName: 'The Turquoise Tide',
    authorName: 'Sofia Gilani',
    rating: 5,
    comment: 'Starlink WiFi was incredibly fast. Swimming pool is huge. Security was extremely professional and polite. Best beach house in Karachi by far.',
    approved: true,
    createdAt: '2026-07-01'
  },
  {
    id: 'rev-15',
    propertyId: 'hb-01',
    propertyName: 'The Azure Sands Retreat',
    authorName: 'Bilal Chawla',
    rating: 4,
    comment: 'Good overall, generator capacity is perfect. Cleanliness was good but could be slightly improved on the beach dunes.',
    approved: true,
    createdAt: '2026-07-02'
  },
  {
    id: 'rev-16',
    propertyId: 'hb-04',
    propertyName: 'The Pearl Beach Villa',
    authorName: 'Faiza Noor',
    rating: 4,
    comment: 'Cozy and romantic cabin for our anniversary. Safe, private, and located on the beautiful French beach rocky strip.',
    approved: true,
    createdAt: '2026-07-02'
  },
  {
    id: 'rev-17',
    propertyId: 'hb-13',
    propertyName: 'The Lighthouse Villa',
    authorName: 'Rehan Alvi',
    rating: 4,
    comment: 'Excellent volley ball court and open deck. Played beach volleyball till sunset. Great location on Hawksbay Block B.',
    approved: true,
    createdAt: '2026-07-03'
  },
  {
    id: 'rev-18',
    propertyId: 'hb-14',
    propertyName: 'The Marine Escape',
    authorName: 'Mariam Kazi',
    rating: 5,
    comment: 'The sweet fresh water supply was excellent and continuous. Bed linen was freshly washed. Host gave us turtle conservation tips.',
    approved: true,
    createdAt: '2026-07-03'
  },
  {
    id: 'rev-19',
    propertyId: 'hb-17',
    propertyName: 'Karachi Beach Shell Beach Resort',
    authorName: 'Sarmad Junejo',
    rating: 5,
    comment: 'The grass lawn is extremely large and ideal for playing cricket. Water slides on pool were highly popular with the children. Perfect family spot.',
    approved: true,
    createdAt: '2026-07-03'
  },
  {
    id: 'rev-20',
    propertyId: 'hb-19',
    propertyName: 'Sunset Coastline Pavilion',
    authorName: 'Saima Yusuf',
    rating: 4,
    comment: 'Tiled floors were squeaky clean. BBQ grill is high quality. Very safe neighborhood.',
    approved: true,
    createdAt: '2026-07-03'
  },
  // Active Approved Reviews up to 25
  {
    id: 'rev-21',
    propertyId: 'hb-02',
    propertyName: 'La Serena Cove',
    authorName: 'Zeeshan Malik',
    rating: 5,
    comment: 'Clean sandy shore and quiet surrounding. Excellent for writing and relaxing. The fiber internet worked perfectly.',
    approved: true,
    createdAt: '2026-06-11'
  },
  {
    id: 'rev-22',
    propertyId: 'hb-03',
    propertyName: 'Turtle Beach Royal Pavilion',
    authorName: 'Javeria Qureshi',
    rating: 5,
    comment: 'Very luxury atmosphere. The gazebo looks fabulous at night with custom lighting. Great value for money.',
    approved: true,
    createdAt: '2026-06-16'
  },
  {
    id: 'rev-23',
    propertyId: 'hb-05',
    propertyName: 'Karachi Beach Crest Estate',
    authorName: 'Mustafa Habib',
    rating: 5,
    comment: 'Double-story house is fully premium. Tiled bathrooms, plush sofa sets, and a large dining table. Host responded immediately to our messages.',
    approved: true,
    createdAt: '2026-06-20'
  },
  {
    id: 'rev-24',
    propertyId: 'hb-06',
    propertyName: 'Ocean Breeze Sanctuary',
    authorName: 'Eshaal Baig',
    rating: 5,
    comment: 'The hammocks were so relaxing. Had an awesome tea session in the evening on the wooden deck.',
    approved: true,
    createdAt: '2026-06-22'
  },
  {
    id: 'rev-25',
    propertyId: 'hb-07',
    propertyName: 'The Palms Mansion',
    authorName: 'Umair Ansari',
    rating: 5,
    comment: 'The pool water is crystal clear and fresh. Truly a resort grade property with high privacy boundary fences.',
    approved: true,
    createdAt: '2026-06-24'
  },
  // Pending reviews (5 count, making it exactly 30 total!)
  {
    id: 'rev-26',
    propertyId: 'hb-01',
    propertyName: 'The Azure Sands Retreat',
    authorName: 'Taha Ahmed',
    rating: 5,
    comment: 'Stunning place. Highly recommended! We got standard custom bedding and the generator backed up the AC instantly during power cuts.',
    approved: false,
    createdAt: '2026-07-03'
  },
  {
    id: 'rev-27',
    propertyId: 'hb-02',
    propertyName: 'La Serena Cove',
    authorName: 'Asma Khan',
    rating: 4,
    comment: 'Lovely garden space and direct sand access. Very relaxing experience, will visit Sandspit again!',
    approved: false,
    createdAt: '2026-07-03'
  },
  {
    id: 'rev-28',
    propertyId: 'hb-03',
    propertyName: 'Turtle Beach Royal Pavilion',
    authorName: 'Daniyal Mirza',
    rating: 5,
    comment: 'This beach house is a fortress of comfort. Pool is sparkling and turtle preservation instructions were great.',
    approved: false,
    createdAt: '2026-07-03'
  },
  {
    id: 'rev-29',
    propertyId: 'hb-05',
    propertyName: 'Karachi Beach Crest Estate',
    authorName: 'Zubair Alvi',
    rating: 5,
    comment: 'Super fast WiFi, spacious bedrooms, excellent sound system. Great place to spend a holiday.',
    approved: false,
    createdAt: '2026-07-03'
  },
  {
    id: 'rev-30',
    propertyId: 'hb-10',
    propertyName: 'Solitude Beach Estate',
    authorName: 'Maheen Jamil',
    rating: 5,
    comment: 'Loved snorkeling on French Beach! The stone villa is extremely unique and charming.',
    approved: false,
    createdAt: '2026-07-03'
  }
];
