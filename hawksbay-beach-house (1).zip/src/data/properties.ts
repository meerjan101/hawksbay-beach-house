/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Property } from '../types';

export const INITIAL_PROPERTIES: Property[] = [
  {
    id: 'hb-01',
    title: 'The Azure Sands Retreat',
    description: 'Experience pure coastal luxury at this stunning front-line Hawksbay estate. Featuring an infinity pool, extensive BBQ deck, and modern interior design, this beach house is perfect for premium corporate events and large family gatherings.',
    pricePerNight: 65000,
    location: 'Hawksbay, Block A',
    bedrooms: 4,
    bathrooms: 4,
    guestCapacity: 25,
    hasPool: true,
    hasBBQ: true,
    hasBeachView: true,
    isFamilyFriendly: true,
    images: [
      'https://images.unsplash.com/photo-1499793983690-e29da59ef1c2?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&w=800&q=80'
    ],
    amenities: ['Private Pool', 'Sandy Beach Access', 'BBQ Grill', 'Air Conditioning', 'Standby Generator', '24/7 Security Guard', 'WiFi', 'Satellite TV', 'Kitchenette'],
    houseRules: [
      'Maximum 25 guests allowed on site.',
      'Loud music is prohibited after 10:00 PM.',
      'Keep the beach clean. Dispose of trash in provided bins.',
      'No pets allowed inside the rooms.'
    ],
    featured: true
  },
  {
    id: 'hb-02',
    title: 'La Serena Cove',
    description: 'Tucked away in a tranquil corner of Sandspit Beach, La Serena offers a peaceful escape from Karachi’s hustle. It features a beautifully manicured lawn, immediate sandy beach walk-out, and high-speed fiber internet.',
    pricePerNight: 45000,
    location: 'Sandspit Beach',
    bedrooms: 3,
    bathrooms: 3,
    guestCapacity: 15,
    hasPool: false,
    hasBBQ: true,
    hasBeachView: true,
    isFamilyFriendly: true,
    images: [
      'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1484154218962-a197022b5858?auto=format&fit=crop&w=800&q=80'
    ],
    amenities: ['Sandy Beach Access', 'BBQ Grill', 'Lush Green Lawn', 'Air Conditioning', 'Standby Generator', 'Security Guard', 'WiFi', 'Kitchenette'],
    houseRules: [
      'Maximum 15 guests allowed.',
      'No glass containers near the shoreline.',
      'Smoking is permitted in outdoor areas only.'
    ],
    featured: true
  },
  {
    id: 'hb-03',
    title: 'Turtle Beach Royal Pavilion',
    description: 'Known for its proximity to turtle nesting sites, this elegant beach house at Turtle Beach combines architectural marvel with premium comforts. Boasting a massive freshwater pool, a private gazebo, and spectacular sunsets.',
    pricePerNight: 85000,
    location: 'Turtle Beach',
    bedrooms: 5,
    bathrooms: 6,
    guestCapacity: 30,
    hasPool: true,
    hasBBQ: true,
    hasBeachView: true,
    isFamilyFriendly: true,
    images: [
      'https://images.unsplash.com/photo-1515263487990-61b07816b324?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1505691938895-1758d7feb511?auto=format&fit=crop&w=800&q=80'
    ],
    amenities: ['Private Pool', 'Gazebo', 'BBQ Area', 'Air Conditioning', 'Heavy Duty Generator', 'CCTV & Security', 'Gated Parking', 'Kitchen', 'Billiard Table'],
    houseRules: [
      'Strictly no littering. Guard turtles nesting sites.',
      'Advance booking deposit is non-refundable within 48 hours of check-in.',
      'Guests must carry National Identity Cards (CNIC).'
    ],
    featured: true
  },
  {
    id: 'hb-04',
    title: 'The Pearl Beach Villa',
    description: 'A cozy, modern 2-bedroom beach cottage perfect for couples and small nuclear families looking for an exclusive weekend getaway at French Beach Karachi.',
    pricePerNight: 35000,
    location: 'French Beach',
    bedrooms: 2,
    bathrooms: 2,
    guestCapacity: 8,
    hasPool: false,
    hasBBQ: true,
    hasBeachView: true,
    isFamilyFriendly: true,
    images: [
      'https://images.unsplash.com/photo-1580587771525-78b9dba3b914?auto=format&fit=crop&w=1200&q=80'
    ],
    amenities: ['Direct Ocean Front', 'BBQ Pit', 'Air Conditioning', 'Generator Backup', 'Security Guard', 'Microwave & Fridge', 'Terrace View'],
    houseRules: [
      'Family-only bookings allowed.',
      'Check-in at 12:00 PM, Check-out at 10:00 AM next day.'
    ],
    featured: false
  },
  {
    id: 'hb-05',
    title: 'Karachi Beach Crest Estate',
    description: 'A stunning double-story architectural icon right on Hawksbay Beach. Featuring a luxury glass lounge facing the Arabian Sea, a sparkling swimming pool, indoor game room, and high-security protocols.',
    pricePerNight: 95000,
    location: 'Hawksbay, Block B',
    bedrooms: 6,
    bathrooms: 7,
    guestCapacity: 35,
    hasPool: true,
    hasBBQ: true,
    hasBeachView: true,
    isFamilyFriendly: true,
    images: [
      'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=800&q=80'
    ],
    amenities: ['Glass Ocean Lounge', 'Swimming Pool', 'Pool Table', 'Foosball Table', 'Sound System', 'BBQ Deck', 'Catering Available', 'Heavy Duty Generator', 'WiFi'],
    houseRules: [
      'Maximum 35 guests.',
      'Music must be turned down after midnight.',
      'Valet parking is available on request.'
    ],
    featured: true
  },
  {
    id: 'hb-06',
    title: 'Ocean Breeze Sanctuary',
    description: 'Relax in this modern sand-stone cottage on Sandspit, featuring open patios, ocean-front hammocks, and custom BBQ areas. Designed to give you an authentic, peaceful rustic beach house feel.',
    pricePerNight: 40000,
    location: 'Sandspit Beach',
    bedrooms: 3,
    bathrooms: 3,
    guestCapacity: 12,
    hasPool: false,
    hasBBQ: true,
    hasBeachView: true,
    isFamilyFriendly: true,
    images: [
      'https://images.unsplash.com/photo-1523217582562-09d0def993a6?auto=format&fit=crop&w=1200&q=80'
    ],
    amenities: ['Beach Hammocks', 'BBQ Pit', 'Covered Patios', 'Air Conditioning', 'Standby Generator', 'Security Guard', 'Self-catering Kitchen'],
    houseRules: [
      'Keep the beach clean.',
      'Children must be supervised near water at all times.'
    ],
    featured: false
  },
  {
    id: 'hb-07',
    title: 'The Palms Mansion',
    description: 'Surrounded by beautiful imported palm trees and custom stone structures, The Palms Hawksbay features an extra-large pool, a sun-lounger deck, and a grand dining hall. Fully air-conditioned rooms with high-end fixtures.',
    pricePerNight: 75000,
    location: 'Hawksbay, Block A',
    bedrooms: 4,
    bathrooms: 5,
    guestCapacity: 20,
    hasPool: true,
    hasBBQ: true,
    hasBeachView: true,
    isFamilyFriendly: true,
    images: [
      'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80',
      'https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?auto=format&fit=crop&w=800&q=80'
    ],
    amenities: ['Extra-Large Pool', 'Sun-lounger Deck', 'Grand Dining Hall', 'BBQ Station', 'Full Air Conditioning', 'WiFi', 'Smart TVs', 'Kitchen with Chef (Optional)', 'Armed Security'],
    houseRules: [
      'No professional photo shoots without pre-authorization.',
      'Littering on beach property is subject to penalty.'
    ],
    featured: false
  },
  {
    id: 'hb-08',
    title: 'Coral Beachfront Cabin',
    description: 'A cozy, beachside cabin with wood paneling and bright interiors at Sandspit. Perfect for a quick family escape or a beachside workcation with reliable internet.',
    pricePerNight: 32000,
    location: 'Sandspit Beach',
    bedrooms: 2,
    bathrooms: 2,
    guestCapacity: 10,
    hasPool: false,
    hasBBQ: true,
    hasBeachView: true,
    isFamilyFriendly: true,
    images: [
      'https://images.unsplash.com/photo-1449034446853-66c86144b0ad?auto=format&fit=crop&w=1200&q=80'
    ],
    amenities: ['Wood Deck', 'BBQ Stand', 'AC in Bedrooms', 'Power Backup', 'Sea View Balcony', 'Security', 'Equipped Kitchen'],
    houseRules: [
      'CNIC copies required for all adult guests.',
      'Check-in: 1:00 PM, Check-out: 11:00 AM.'
    ],
    featured: false
  },
  {
    id: 'hb-09',
    title: 'The Golden Crest Villa',
    description: 'A newly constructed modern villa at Turtle Beach with golden sunset vistas. Enjoy a private indoor plunge pool, high-walled secure perimeter, and comfortable beds with premium linens.',
    pricePerNight: 70000,
    location: 'Turtle Beach',
    bedrooms: 4,
    bathrooms: 4,
    guestCapacity: 18,
    hasPool: true,
    hasBBQ: true,
    hasBeachView: true,
    isFamilyFriendly: true,
    images: [
      'https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?auto=format&fit=crop&w=1200&q=80'
    ],
    amenities: ['Indoor Plunge Pool', 'High Security Wall', 'BBQ Counter', 'WiFi', 'Premium Bedding', 'Generator Backup', 'Secured Parking', 'Microwave/Fridge'],
    houseRules: [
      'Quiet hours begin at 11:00 PM.',
      'No deep frying inside the indoor kitchen.'
    ],
    featured: false
  },
  {
    id: 'hb-10',
    title: 'Solitude Beach Estate',
    description: 'Escape the crowd entirely in this remote luxury estate located on the pristine sands of French Beach. Known for its rocky cove and crystalline waters, French Beach offers unmatched exclusivity.',
    pricePerNight: 90000,
    location: 'French Beach',
    bedrooms: 5,
    bathrooms: 5,
    guestCapacity: 22,
    hasPool: true,
    hasBBQ: true,
    hasBeachView: true,
    isFamilyFriendly: true,
    images: [
      'https://images.unsplash.com/photo-1613977257363-707ba9348227?auto=format&fit=crop&w=1200&q=80'
    ],
    amenities: ['Private Rocky Cove Pool', 'Crystal Clear Waters Access', 'Huge Deck Lounge', 'Barbecue Station', 'Air Conditioning', 'Heavy Generator', 'Guards & Staff', 'Billiards Room'],
    houseRules: [
      'Strictly family bookings or corporate groups.',
      'Submitting guest names in advance is mandatory.'
    ],
    featured: true
  },
  {
    id: 'hb-11',
    title: 'Seaside Serenity Haven',
    description: 'Enjoy refreshing breeze and uninterrupted ocean views from the massive terrace of this Sandspit villa. Fully equipped kitchen, clean washrooms, and secure beach access pathways.',
    pricePerNight: 38000,
    location: 'Sandspit Beach',
    bedrooms: 3,
    bathrooms: 3,
    guestCapacity: 15,
    hasPool: false,
    hasBBQ: true,
    hasBeachView: true,
    isFamilyFriendly: true,
    images: [
      'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?auto=format&fit=crop&w=1200&q=80'
    ],
    amenities: ['Sea View Terrace', 'Direct Beach Gate', 'BBQ Grill', 'Air Conditioning', 'Standby Generator', '24/7 Security'],
    houseRules: [
      'Guests are requested to bring their own swimming costumes.',
      'Littering in the beach area is strictly prohibited.'
    ],
    featured: false
  },
  {
    id: 'hb-12',
    title: 'The Sandspit Oasis',
    description: 'Features a beautiful, custom-designed freshwater swimming pool, a wide beach-side gazebo, and highly comfortable beds. Ideal for weekend parties and get-togethers.',
    pricePerNight: 55000,
    location: 'Sandspit Beach',
    bedrooms: 3,
    bathrooms: 4,
    guestCapacity: 20,
    hasPool: true,
    hasBBQ: true,
    hasBeachView: true,
    isFamilyFriendly: true,
    images: [
      'https://images.unsplash.com/photo-1582268611958-ebfd161ef9cf?auto=format&fit=crop&w=1200&q=80'
    ],
    amenities: ['Freshwater Pool', 'Gazebo Lounge', 'Barbecue Pit', 'AC Bedrooms', 'Power Generator', 'Security Guard', 'Free WiFi'],
    houseRules: [
      'No deep water diving inside the pool.',
      'Check-out is strictly by 11:00 AM.'
    ],
    featured: false
  },
  {
    id: 'hb-13',
    title: 'The Lighthouse Villa',
    description: 'An iconic Hawksbay beach house sitting next to landmark rocky structures. Offers massive open roofs, modern bathrooms, a designated volleyball court area on the beach, and full catering support.',
    pricePerNight: 60000,
    location: 'Hawksbay, Block B',
    bedrooms: 4,
    bathrooms: 4,
    guestCapacity: 25,
    hasPool: false,
    hasBBQ: true,
    hasBeachView: true,
    isFamilyFriendly: true,
    images: [
      'https://images.unsplash.com/photo-1613490493576-7fde63acd811?auto=format&fit=crop&w=1200&q=80'
    ],
    amenities: ['Panoramic Roof', 'Beach Volleyball Pitch', 'BBQ Pit', 'Catering Station', 'Air Conditioning', 'Standby Generator', 'WiFi', 'CCTV Security'],
    houseRules: [
      'Advance reservation is mandatory.',
      'Refunds are subject to our cancellation policy.'
    ],
    featured: false
  },
  {
    id: 'hb-14',
    title: 'The Marine Escape',
    description: 'A cozy beach house right on Turtle Beach. It features a private terrace overlooking turtle nests and the Arabian sea. Excellent backup power and fresh tap water supply (a luxury at Karachi beaches!).',
    pricePerNight: 48000,
    location: 'Turtle Beach',
    bedrooms: 3,
    bathrooms: 3,
    guestCapacity: 12,
    hasPool: false,
    hasBBQ: true,
    hasBeachView: true,
    isFamilyFriendly: true,
    images: [
      'https://images.unsplash.com/photo-1592595896551-12b371d546d5?auto=format&fit=crop&w=1200&q=80'
    ],
    amenities: ['Turtle Spotting Terrace', 'Fresh Water Supply', 'BBQ Stand', 'AC Rooms', 'Generator Backup', 'Security guards', 'Kitchen Access'],
    houseRules: [
      'Turtle conservation rules apply. Do not shine strong searchlights on the beach during night.',
      'No fireworks allowed.'
    ],
    featured: false
  },
  {
    id: 'hb-15',
    title: 'Blue Wave Horizon Club',
    description: 'A luxurious beach mansion featuring a large deck, deep swimming pool, and multiple bedrooms with sea-facing balconies. Perfect for high-profile client hosting and modern beach festivals.',
    pricePerNight: 110000,
    location: 'Hawksbay, Block A',
    bedrooms: 6,
    bathrooms: 6,
    guestCapacity: 40,
    hasPool: true,
    hasBBQ: true,
    hasBeachView: true,
    isFamilyFriendly: true,
    images: [
      'https://images.unsplash.com/photo-1568605114967-8130f3a36994?auto=format&fit=crop&w=1200&q=80'
    ],
    amenities: ['Mansion Lounge', 'Deep Pool', 'Sea-facing Balconies', 'BBQ Pit & Buffet Deck', 'High Capacity Generator', 'CCTV & Elite Security Guards', 'WiFi', 'Kitchen Chef Available'],
    houseRules: [
      'Any damage to property assets will be billed directly to the booker.',
      'Maximum 40 attendees.'
    ],
    featured: true
  },
  {
    id: 'hb-16',
    title: 'Emerald Bay Cabin',
    description: 'A rustic, elegant wooden chalet style cabin situated at Sandspit, designed with gorgeous interior woodwork. Ideal for creatives and groups who want inspiration by the tides.',
    pricePerNight: 36000,
    location: 'Sandspit Beach',
    bedrooms: 2,
    bathrooms: 2,
    guestCapacity: 10,
    hasPool: false,
    hasBBQ: true,
    hasBeachView: true,
    isFamilyFriendly: true,
    images: [
      'https://images.unsplash.com/photo-1510798831971-661eb04b3739?auto=format&fit=crop&w=1200&q=80'
    ],
    amenities: ['Chalet Wooden Decor', 'Ocean Front Patios', 'AC Lounge', 'Power Generator', '24/7 Security', 'Microwave/Fridge'],
    houseRules: [
      'Strict noise limit after 10:00 PM.',
      'Cleanliness must be maintained.'
    ],
    featured: false
  },
  {
    id: 'hb-17',
    title: 'Karachi Shell Beach Resort',
    description: 'A grand retreat on Turtle Beach featuring a sprawling grassy park, swimming pool, water slides for children, and multiple seaside gazebos. A true family paradise.',
    pricePerNight: 80000,
    location: 'Turtle Beach',
    bedrooms: 5,
    bathrooms: 5,
    guestCapacity: 30,
    hasPool: true,
    hasBBQ: true,
    hasBeachView: true,
    isFamilyFriendly: true,
    images: [
      'https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&w=1200&q=80'
    ],
    amenities: ['Grassy Play Area', 'Swimming Pool & Water Slides', 'Seaside Gazebos', 'BBQ Pit', 'Standby Power Generator', 'Armed Security Guard', 'WiFi', 'Kitchen Setup'],
    houseRules: [
      'Children must be accompanied by adults near slides and pool.',
      'Please present CNIC during entry.'
    ],
    featured: false
  },
  {
    id: 'hb-18',
    title: 'The Pebble Cove French Beach',
    description: 'A premium, handcrafted stone cabin located in the rocky, scenic French Beach. Perfect for snorkeling lovers, dynamic cliff views, and clear water swimming.',
    pricePerNight: 65000,
    location: 'French Beach',
    bedrooms: 3,
    bathrooms: 3,
    guestCapacity: 12,
    hasPool: false,
    hasBBQ: true,
    hasBeachView: true,
    isFamilyFriendly: true,
    images: [
      'https://images.unsplash.com/photo-1507089947368-19c1da9775ae?auto=format&fit=crop&w=1200&q=80'
    ],
    amenities: ['Scenic Cliff Deck', 'Snorkeling Spots Walkout', 'Stone BBQ Pit', 'AC Bedrooms', 'Generator Backup', 'Security Guard', 'Espresso Machine'],
    houseRules: [
      'No diving off the rocks during high tide.',
      'Snorkeling equipment available upon request.'
    ],
    featured: false
  },
  {
    id: 'hb-19',
    title: 'Sunset Coastline Pavilion',
    description: 'A modern, secure, and beautiful beach house on Hawksbay Beach, Block B. Features broad beachfront seating, custom swings for families, clear tap water, and clean tiled floors.',
    pricePerNight: 42000,
    location: 'Hawksbay, Block B',
    bedrooms: 3,
    bathrooms: 3,
    guestCapacity: 15,
    hasPool: false,
    hasBBQ: true,
    hasBeachView: true,
    isFamilyFriendly: true,
    images: [
      'https://images.unsplash.com/photo-1518780664697-55e3ad937233?auto=format&fit=crop&w=1200&q=80'
    ],
    amenities: ['Broad Beachfront Patios', 'Seaside Swings', 'BBQ Grill Set', 'Air Conditioning', 'Standby Generator', 'Security Guard', 'Fitted Kitchen'],
    houseRules: [
      'Max 15 guests permitted.',
      'Observe safe swimming guidelines.'
    ],
    featured: false
  },
  {
    id: 'hb-20',
    title: 'The Turquoise Tide',
    description: 'Designed as a coastal fortress of relaxation at Hawksbay. Boasts massive security protocols, high-walled gardens, a beautiful sea-view pool, luxury furniture, and fully-equipped serveries.',
    pricePerNight: 100000,
    location: 'Hawksbay, Block A',
    bedrooms: 5,
    bathrooms: 6,
    guestCapacity: 25,
    hasPool: true,
    hasBBQ: true,
    hasBeachView: true,
    isFamilyFriendly: true,
    images: [
      'https://images.unsplash.com/photo-1520250497591-112f2f40a3f4?auto=format&fit=crop&w=1200&q=80'
    ],
    amenities: ['Sea-view Pool', 'High Security Guard Rails', 'Luxury Patios', 'Fitted Kitchen Serveries', 'Armed Security Team', 'Heavy-duty 100kVA Generator', 'High-speed Starlink WiFi'],
    houseRules: [
      'Security checks are mandatory at entrance gate.',
      'Advance reservation only.'
    ],
    featured: true
  }
];
