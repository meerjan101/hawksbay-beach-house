/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, Bed, Bath, Users, ShieldAlert, Waves, Flame, Sparkles, 
  Tv, Wifi, Check, Heart, Star, Calendar, MessageSquarePlus, MessageSquare, AlertCircle,
  ChevronLeft, ChevronRight, Maximize2, Play, Pause, X, ZoomIn, ZoomOut
} from 'lucide-react';
import { Property, Review, Booking } from '../types';

interface PropertyDetailsProps {
  property: Property;
  onBack: () => void;
  reviews: Review[];
  onSubmitBooking: (bookingData: Omit<Booking, 'id' | 'propertyName' | 'totalPrice' | 'createdAt' | 'status' | 'paymentStatus'>) => void;
  onSubmitReview: (reviewData: Omit<Review, 'id' | 'propertyName' | 'approved' | 'createdAt'>) => void;
  isFavorite: boolean;
  onToggleFavorite: (id: string) => void;
}

export default function PropertyDetails({
  property,
  onBack,
  reviews,
  onSubmitBooking,
  onSubmitReview,
  isFavorite,
  onToggleFavorite
}: PropertyDetailsProps) {
  const [currentImgIndex, setCurrentImgIndex] = useState(0);
  const activeImage = property.images[currentImgIndex];
  
  // Lightbox and slideshow autoplay states
  const [isLightboxOpen, setIsLightboxOpen] = useState(false);
  const [lightboxIndex, setLightboxIndex] = useState(0);
  const [isAutoplay, setIsAutoplay] = useState(false);
  const [lightboxZoom, setLightboxZoom] = useState(false);
  const [touchStartX, setTouchStartX] = useState<number | null>(null);

  // Slideshow Autoplay Timer Effect
  useEffect(() => {
    if (!isAutoplay) return;
    const interval = setInterval(() => {
      setCurrentImgIndex((prev) => (prev + 1) % property.images.length);
    }, 3500);
    return () => clearInterval(interval);
  }, [isAutoplay, property.images.length]);

  // Lightbox keyboard navigation & escape close key handlers
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isLightboxOpen) return;
      if (e.key === 'Escape') {
        setIsLightboxOpen(false);
        setLightboxZoom(false);
      } else if (e.key === 'ArrowRight') {
        setLightboxIndex((prev) => (prev + 1) % property.images.length);
        setLightboxZoom(false);
      } else if (e.key === 'ArrowLeft') {
        setLightboxIndex((prev) => (prev - 1 + property.images.length) % property.images.length);
        setLightboxZoom(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isLightboxOpen, property.images.length]);

  // Touch Swipe Handlers for carousel & lightbox
  const handleTouchStart = (e: React.TouchEvent) => {
    setTouchStartX(e.touches[0].clientX);
  };

  const handleTouchEnd = (
    e: React.TouchEvent, 
    onSwipeLeft: () => void, 
    onSwipeRight: () => void
  ) => {
    if (touchStartX === null) return;
    const touchEndX = e.changedTouches[0].clientX;
    const diff = touchStartX - touchEndX;
    if (Math.abs(diff) > 50) { // minimum threshold (50px)
      if (diff > 0) {
        onSwipeLeft(); // Swipe Left -> Next
      } else {
        onSwipeRight(); // Swipe Right -> Prev
      }
    }
    setTouchStartX(null);
  };

  const [checkIn, setCheckIn] = useState('');
  const [checkOut, setCheckOut] = useState('');
  const [guests, setGuests] = useState(15);
  const [guestName, setGuestName] = useState('');
  const [guestEmail, setGuestEmail] = useState('');
  const [guestPhone, setGuestPhone] = useState('');
  
  const [reviewName, setReviewName] = useState('');
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewComment, setReviewComment] = useState('');

  const [bookingSuccess, setBookingSuccess] = useState<string | null>(null);
  const [reviewSuccess, setReviewSuccess] = useState<string | null>(null);

  // Simple price and days calculator
  const calculateNights = () => {
    if (!checkIn || !checkOut) return 0;
    const date1 = new Date(checkIn);
    const date2 = new Date(checkOut);
    const diffTime = Math.abs(date2.getTime() - date1.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays > 0 ? diffDays : 1;
  };

  const nights = calculateNights();
  const totalPrice = nights * property.pricePerNight;

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!checkIn || !checkOut || !guestName || !guestEmail || !guestPhone) {
      alert('Please fill out all booking fields');
      return;
    }

    onSubmitBooking({
      propertyId: property.id,
      checkIn,
      checkOut,
      guests,
      guestName,
      guestEmail,
      guestPhone
    });

    const mockId = 'BK-' + Math.floor(100000 + Math.random() * 900000);
    setBookingSuccess(`Booking request sent successfully! Your reference ID is: ${mockId}. The Hawksbay operations moderator will contact you via WhatsApp to approve.`);
    
    // Reset fields
    setCheckIn('');
    setCheckOut('');
    setGuestName('');
    setGuestEmail('');
    setGuestPhone('');
  };

  const handleReviewSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!reviewName || !reviewComment) {
      alert('Please fill in both name and comment');
      return;
    }

    onSubmitReview({
      propertyId: property.id,
      authorName: reviewName,
      rating: reviewRating,
      comment: reviewComment
    });

    setReviewSuccess('Your review has been submitted for Admin approval! Thank you.');
    setReviewName('');
    setReviewRating(5);
    setReviewComment('');
  };

  const activeReviews = reviews.filter(r => r.propertyId === property.id && r.approved);

  return (
    <div className="max-w-7xl mx-auto px-6 py-8">
      {/* Back button and Favorite Trigger */}
      <div className="flex justify-between items-center mb-8">
        <button
          onClick={onBack}
          className="flex items-center gap-2 font-bold text-sm text-slate-600 hover:text-sky-600 transition group cursor-pointer"
        >
          <ArrowLeft size={16} className="group-hover:-translate-x-1 transition" />
          <span>Back to Beach Houses</span>
        </button>

        <button
          onClick={() => onToggleFavorite(property.id)}
          className={`flex items-center gap-2 px-4 py-2 rounded-2xl border transition shadow-sm cursor-pointer ${
            isFavorite 
              ? 'bg-rose-50 text-rose-600 border-rose-100' 
              : 'bg-white text-slate-600 hover:text-rose-500 border-slate-100'
          }`}
        >
          <Heart size={16} fill={isFavorite ? 'currentColor' : 'none'} />
          <span className="text-xs font-bold uppercase tracking-wider">{isFavorite ? 'Saved as Favorite' : 'Save Property'}</span>
        </button>
      </div>

      {/* Main Grid Content */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 items-start">
        {/* Left Side: Images & Info (2 Columns) */}
        <div className="lg:col-span-2 space-y-10">
          
          {/* Header Specs */}
          <div>
            <span className="text-xs font-black text-sky-600 tracking-widest uppercase block mb-1.5">{property.location}</span>
            <h1 className="text-3xl lg:text-4xl font-extrabold text-slate-900 tracking-tight leading-tight mb-4">
              {property.title}
            </h1>
            
            <div className="flex flex-wrap items-center gap-6 text-slate-500 font-semibold text-sm">
              <div className="flex items-center gap-2">
                <Bed size={16} className="text-sky-600" />
                <span>{property.bedrooms} Bedrooms</span>
              </div>
              <div className="flex items-center gap-2">
                <Bath size={16} className="text-sky-600" />
                <span>{property.bathrooms} Bathrooms</span>
              </div>
              <div className="flex items-center gap-2">
                <Users size={16} className="text-sky-600" />
                <span>Up to {property.guestCapacity} Guests capacity</span>
              </div>
              {property.hasPool && (
                <div className="flex items-center gap-2 text-emerald-600 font-bold">
                  <Waves size={16} className="text-emerald-500" />
                  <span>Freshwater Pool</span>
                </div>
              )}
            </div>
          </div>

          {/* Interactive Image Gallery with Swipeable Carousel */}
          <div className="space-y-4">
            <div 
              className="relative rounded-3xl overflow-hidden h-[350px] lg:h-[480px] bg-slate-900 shadow-lg group select-none"
              onTouchStart={handleTouchStart}
              onTouchEnd={(e) => handleTouchEnd(
                e, 
                () => setCurrentImgIndex((prev) => (prev + 1) % property.images.length),
                () => setCurrentImgIndex((prev) => (prev - 1 + property.images.length) % property.images.length)
              )}
            >
              {/* Carousel Image */}
              <img
                src={activeImage}
                alt={`${property.title} - View ${currentImgIndex + 1}`}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
              />

              {/* Gradient overlays */}
              <div className="absolute inset-x-0 top-0 h-16 bg-gradient-to-b from-black/40 to-transparent pointer-events-none" />
              <div className="absolute inset-x-0 bottom-0 h-20 bg-gradient-to-t from-black/50 to-transparent pointer-events-none" />

              {/* Media Controls Overlay */}
              <div className="absolute top-4 right-4 flex items-center gap-2">
                {/* Autoplay Slideshow Toggle */}
                <button
                  onClick={() => setIsAutoplay(!isAutoplay)}
                  className={`flex items-center gap-1 px-3 py-1.5 rounded-full text-xs font-black uppercase tracking-wider backdrop-blur-md transition-all shadow-md cursor-pointer ${
                    isAutoplay 
                      ? 'bg-emerald-500/90 hover:bg-emerald-600 text-white animate-pulse' 
                      : 'bg-black/40 hover:bg-black/60 text-white border border-white/10'
                  }`}
                  title={isAutoplay ? "Pause Slideshow" : "Play Slideshow"}
                >
                  {isAutoplay ? <Pause size={12} fill="currentColor" /> : <Play size={12} fill="currentColor" />}
                  <span>{isAutoplay ? 'Playing' : 'Autoplay'}</span>
                </button>

                {/* Lightbox Trigger Button */}
                <button
                  onClick={() => {
                    setLightboxIndex(currentImgIndex);
                    setIsLightboxOpen(true);
                  }}
                  className="bg-black/40 hover:bg-black/60 border border-white/10 text-white p-2 rounded-full backdrop-blur-md transition shadow-md cursor-pointer flex items-center justify-center"
                  title="Expand Fullscreen Lightbox"
                >
                  <Maximize2 size={14} />
                </button>
              </div>

              {/* Counter Badge */}
              <div className="absolute top-4 left-4 bg-black/40 border border-white/10 text-white text-[10px] font-black uppercase tracking-widest px-3 py-1.5 rounded-full backdrop-blur-md">
                {currentImgIndex + 1} / {property.images.length}
              </div>

              {/* Swipe Left Arrow */}
              {property.images.length > 1 && (
                <button
                  onClick={() => setCurrentImgIndex((prev) => (prev - 1 + property.images.length) % property.images.length)}
                  className="absolute left-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white text-slate-800 hover:text-sky-600 p-2.5 rounded-full shadow-lg md:opacity-0 md:group-hover:opacity-100 transition-all duration-300 transform md:-translate-x-2 md:group-hover:translate-x-0 cursor-pointer flex items-center justify-center border border-slate-100"
                >
                  <ChevronLeft size={20} />
                </button>
              )}

              {/* Swipe Right Arrow */}
              {property.images.length > 1 && (
                <button
                  onClick={() => setCurrentImgIndex((prev) => (prev + 1) % property.images.length)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 bg-white/90 hover:bg-white text-slate-800 hover:text-sky-600 p-2.5 rounded-full shadow-lg md:opacity-0 md:group-hover:opacity-100 transition-all duration-300 transform md:translate-x-2 md:group-hover:translate-x-0 cursor-pointer flex items-center justify-center border border-slate-100"
                >
                  <ChevronRight size={20} />
                </button>
              )}

              {/* Dot Indicators */}
              {property.images.length > 1 && (
                <div className="absolute bottom-4 inset-x-0 flex justify-center gap-1.5">
                  {property.images.map((_, i) => (
                    <button
                      key={i}
                      onClick={() => setCurrentImgIndex(i)}
                      className={`h-2 rounded-full transition-all duration-300 cursor-pointer ${
                        currentImgIndex === i ? 'w-6 bg-white' : 'w-2 bg-white/50 hover:bg-white/80'
                      }`}
                    />
                  ))}
                </div>
              )}
            </div>

            {/* Thumbnails list */}
            {property.images.length > 1 && (
              <div className="flex gap-3 overflow-x-auto pb-1.5 scrollbar-thin scrollbar-thumb-slate-200">
                {property.images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      setCurrentImgIndex(i);
                      setIsAutoplay(false); // Stop autoplay on user interaction
                    }}
                    className={`w-24 h-16 rounded-xl overflow-hidden border-2 shrink-0 transition-all relative ${
                      currentImgIndex === i ? 'border-sky-600 ring-2 ring-sky-100' : 'border-slate-100 hover:border-sky-300'
                    }`}
                  >
                    <img src={img} alt={`Thumb ${i}`} className="w-full h-full object-cover" />
                    {currentImgIndex === i && (
                      <div className="absolute inset-0 bg-sky-500/10 pointer-events-none" />
                    )}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Full description */}
          <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
            <h2 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-2">
              <Sparkles size={18} className="text-sky-600" />
              <span>About this Beach House</span>
            </h2>
            <p className="text-slate-600 leading-relaxed text-base whitespace-pre-line">{property.description}</p>
          </div>

          {/* Amenities details */}
          <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
            <h2 className="text-xl font-bold text-slate-900 mb-6">Standard Amenities Provided</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {property.amenities.map((amenity, idx) => (
                <div key={idx} className="flex items-center gap-3 text-slate-600 font-semibold text-sm">
                  <div className="bg-sky-50 text-sky-600 p-1.5 rounded-lg">
                    <Check size={14} />
                  </div>
                  <span>{amenity}</span>
                </div>
              ))}
            </div>
          </div>

          {/* House Rules & Policies */}
          <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm border-l-4 border-l-sky-500">
            <h2 className="text-xl font-bold text-slate-900 mb-4 flex items-center gap-2">
              <ShieldAlert size={18} className="text-sky-600" />
              <span>Security Policies & House Rules</span>
            </h2>
            <ul className="space-y-3.5 text-sm font-semibold text-slate-600">
              {property.houseRules.map((rule, idx) => (
                <li key={idx} className="flex items-start gap-2.5">
                  <span className="bg-sky-100 text-sky-700 w-5 h-5 rounded-full flex items-center justify-center text-xs mt-0.5 shrink-0">{idx + 1}</span>
                  <span className="leading-relaxed">{rule}</span>
                </li>
              ))}
              <li className="flex items-start gap-2.5 text-slate-500 font-medium">
                <span className="bg-slate-100 text-slate-600 w-5 h-5 rounded-full flex items-center justify-center text-xs mt-0.5 shrink-0">•</span>
                <span className="leading-relaxed">All adult guests must bring valid CNIC copies during check-in.</span>
              </li>
            </ul>
          </div>

          {/* Visual Availability Calendar */}
          <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
            <h2 className="text-xl font-bold text-slate-900 mb-2 flex items-center gap-2">
              <Calendar size={18} className="text-sky-600" />
              <span>Availability Calendar</span>
            </h2>
            <p className="text-slate-400 text-xs font-semibold uppercase tracking-wider mb-6">Interactive weekend selection preview</p>
            
            <div className="grid grid-cols-7 gap-2 text-center text-xs font-bold text-slate-400 border-b border-slate-50 pb-3">
              <span>MON</span><span>TUE</span><span>WED</span><span>THU</span><span>FRI</span><span>SAT</span><span>SUN</span>
            </div>
            <div className="grid grid-cols-7 gap-2 mt-4 text-xs font-bold">
              {Array.from({ length: 28 }).map((_, idx) => {
                const day = idx + 1;
                const isBooked = day % 7 === 5 || day % 7 === 6; // Simulate weekends booked
                return (
                  <div
                    key={idx}
                    className={`p-3.5 rounded-xl flex flex-col items-center justify-center transition-all ${
                      isBooked
                        ? 'bg-rose-50 text-rose-500 line-through cursor-not-allowed'
                        : 'bg-slate-50 text-slate-700 hover:bg-sky-50 hover:text-sky-600 cursor-pointer'
                    }`}
                  >
                    <span>{day}</span>
                    <span className="text-[8px] uppercase tracking-wider block mt-1">
                      {isBooked ? 'Booked' : 'Free'}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Review Segment */}
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
              <MessageSquare size={22} className="text-sky-600" />
              <span>Reviews & Ratings ({activeReviews.length})</span>
            </h2>

            {/* Approved Reviews List */}
            {activeReviews.length > 0 ? (
              <div className="space-y-4">
                {activeReviews.map((rev) => (
                  <div key={rev.id} className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h4 className="font-bold text-slate-900">{rev.authorName}</h4>
                        <span className="text-[10px] text-slate-400 font-bold">{rev.createdAt}</span>
                      </div>
                      <div className="flex gap-0.5 text-amber-500">
                        {Array.from({ length: rev.rating }).map((_, rIdx) => (
                          <Star key={rIdx} size={12} fill="currentColor" />
                        ))}
                      </div>
                    </div>
                    <p className="text-slate-600 text-sm leading-relaxed">{rev.comment}</p>
                  </div>
                ))}
              </div>
            ) : (
              <div className="bg-white p-8 rounded-3xl border border-dashed border-slate-200 text-center">
                <p className="text-slate-500 text-sm">No reviews posted yet for this listing. Be the first to leave a feedback!</p>
              </div>
            )}

            {/* Submit Review Form */}
            <div className="bg-sky-50/50 border border-sky-100 p-8 rounded-3xl space-y-4">
              <h3 className="text-lg font-bold text-slate-900 flex items-center gap-1.5">
                <MessageSquarePlus size={18} className="text-sky-600" />
                <span>Write a Guest Review</span>
              </h3>
              
              {reviewSuccess && (
                <div className="bg-emerald-100 border border-emerald-200 text-emerald-800 p-4 rounded-xl text-sm font-semibold flex items-center gap-2">
                  <Check size={16} />
                  <span>{reviewSuccess}</span>
                </div>
              )}

              <form onSubmit={handleReviewSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1">YOUR NAME</label>
                    <input
                      type="text"
                      value={reviewName}
                      onChange={(e) => setReviewName(e.target.value)}
                      placeholder="e.g., Zainab Khan"
                      required
                      className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm focus:border-sky-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1">STAR RATING</label>
                    <select
                      value={reviewRating}
                      onChange={(e) => setReviewRating(Number(e.target.value))}
                      className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm"
                    >
                      <option value="5">5 Stars (Excellent)</option>
                      <option value="4">4 Stars (Very Good)</option>
                      <option value="3">3 Stars (Good)</option>
                      <option value="2">2 Stars (Average)</option>
                      <option value="1">1 Star (Poor)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">COMMENT</label>
                  <textarea
                    rows={4}
                    value={reviewComment}
                    onChange={(e) => setReviewComment(e.target.value)}
                    placeholder="Describe your overall experience at this beach house..."
                    required
                    className="w-full bg-white border border-slate-200 rounded-xl px-4 py-3 text-sm focus:border-sky-500"
                  ></textarea>
                </div>

                <button
                  type="submit"
                  className="bg-sky-600 hover:bg-sky-800 text-white font-extrabold text-xs uppercase tracking-wider px-6 py-3 rounded-2xl shadow-md transition cursor-pointer"
                >
                  Submit Review
                </button>
              </form>
            </div>
          </div>
        </div>

        {/* Right Side: Booking Form (1 Column Sticky) */}
        <div>
          <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-xl sticky top-28 space-y-6">
            
            {/* Price Heading */}
            <div className="flex justify-between items-end border-b border-slate-50 pb-5">
              <div>
                <span className="text-3xl font-black text-slate-900">PKR {property.pricePerNight.toLocaleString()}</span>
                <span className="text-[10px] text-slate-400 font-bold uppercase block mt-1">per night</span>
              </div>
              <div className="bg-sky-50 px-3 py-1.5 rounded-full text-xs font-bold text-sky-800 flex items-center gap-1">
                <Star size={12} className="text-amber-500 fill-amber-500" />
                <span>4.9</span>
              </div>
            </div>

            {bookingSuccess ? (
              <div className="bg-emerald-50 border border-emerald-100 text-emerald-800 p-6 rounded-2xl space-y-3.5">
                <div className="bg-emerald-600 text-white w-10 h-10 rounded-full flex items-center justify-center font-bold">
                  ✓
                </div>
                <h4 className="font-extrabold text-base">Request Registered</h4>
                <p className="text-xs leading-relaxed font-semibold">{bookingSuccess}</p>
                <button
                  onClick={() => setBookingSuccess(null)}
                  className="text-xs font-black uppercase text-emerald-700 hover:underline cursor-pointer"
                >
                  Book another date
                </button>
              </div>
            ) : (
              <form onSubmit={handleBookingSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[10px] font-black text-slate-500 mb-1">CHECK-IN</label>
                    <input
                      type="date"
                      value={checkIn}
                      onChange={(e) => setCheckIn(e.target.value)}
                      required
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-xs font-semibold focus:border-sky-500 focus:ring-1 focus:ring-sky-500"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black text-slate-500 mb-1">CHECK-OUT</label>
                    <input
                      type="date"
                      value={checkOut}
                      onChange={(e) => setCheckOut(e.target.value)}
                      required
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-xs font-semibold focus:border-sky-500 focus:ring-1 focus:ring-sky-500"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[10px] font-black text-slate-500 mb-1">GUEST CAPACITY</label>
                  <input
                    type="number"
                    value={guests}
                    onChange={(e) => setGuests(Number(e.target.value))}
                    min={1}
                    max={property.guestCapacity}
                    required
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-xs font-semibold"
                  />
                  <span className="text-[10px] text-slate-400 font-medium block mt-1">Maximum limit: {property.guestCapacity} guests</span>
                </div>

                <div>
                  <label className="block text-[10px] font-black text-slate-500 mb-1">YOUR FULL NAME</label>
                  <input
                    type="text"
                    value={guestName}
                    onChange={(e) => setGuestName(e.target.value)}
                    required
                    placeholder="Kamran Shah"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-xs font-semibold"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-black text-slate-500 mb-1">EMAIL ADDRESS</label>
                  <input
                    type="email"
                    value={guestEmail}
                    onChange={(e) => setGuestEmail(e.target.value)}
                    required
                    placeholder="kamran@domain.com"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-xs font-semibold"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-black text-slate-500 mb-1">WHATSAPP / PHONE</label>
                  <input
                    type="text"
                    value={guestPhone}
                    onChange={(e) => setGuestPhone(e.target.value)}
                    required
                    placeholder="e.g. +92 300 1234567"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-xs font-semibold"
                  />
                </div>

                {nights > 0 && (
                  <div className="bg-sky-50/50 p-4 rounded-2xl border border-sky-100 text-xs font-bold space-y-2">
                    <div className="flex justify-between">
                      <span className="text-slate-500">PKR {property.pricePerNight.toLocaleString()} × {nights} Nights</span>
                      <span className="text-slate-900">PKR {totalPrice.toLocaleString()}</span>
                    </div>
                    <div className="border-t border-sky-100 pt-2 flex justify-between text-sky-900">
                      <span>Total Estimated Price</span>
                      <span>PKR {totalPrice.toLocaleString()}</span>
                    </div>
                  </div>
                )}

                {/* Pay on arrival disclaimer info box */}
                <div className="bg-amber-50 p-3.5 rounded-2xl text-[11px] text-amber-800 leading-relaxed border border-amber-100 flex gap-2">
                  <AlertCircle size={15} className="text-amber-600 shrink-0 mt-0.5" />
                  <div>
                    <strong>Pay On Arrival Facility Active</strong><br />
                    There is no online payment required. Your booking goes as "Pending" and is verified manually by our moderator team.
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-sky-600 hover:bg-sky-800 text-white font-black text-xs uppercase tracking-wider py-4 rounded-2xl shadow-lg hover:shadow-xl transition cursor-pointer"
                >
                  Submit Request
                </button>
              </form>
            )}
          </div>
        </div>
      </div>

      {/* Immersive Lightbox Viewer Portal */}
      {isLightboxOpen && (
        <div className="fixed inset-0 z-55 bg-slate-950/98 backdrop-blur-xl flex flex-col justify-between p-4 md:p-8 select-none animate-fade-in">
          {/* Lightbox Top Bar */}
          <div className="flex justify-between items-center z-10">
            <div className="text-white space-y-1">
              <h3 className="text-sm font-black tracking-wider text-sky-400 uppercase">Gallery Viewer</h3>
              <p className="text-xs font-semibold text-slate-400">{property.title} • Image {lightboxIndex + 1} of {property.images.length}</p>
            </div>

            <div className="flex items-center gap-2">
              {/* Zoom Button */}
              <button
                onClick={() => setLightboxZoom(!lightboxZoom)}
                className="bg-slate-900/80 border border-slate-800 text-slate-300 hover:text-white px-3 py-2 rounded-xl backdrop-blur-md transition shadow-md cursor-pointer flex items-center gap-1.5 text-xs font-bold"
                title="Toggle Zoom Details"
              >
                {lightboxZoom ? <ZoomOut size={16} /> : <ZoomIn size={16} />}
                <span className="hidden sm:inline">{lightboxZoom ? 'Zoom Out' : 'Zoom In'}</span>
              </button>

              {/* Close Button */}
              <button
                onClick={() => {
                  setIsLightboxOpen(false);
                  setLightboxZoom(false);
                }}
                className="bg-slate-900/80 border border-slate-800 text-slate-300 hover:text-rose-500 p-2 rounded-xl backdrop-blur-md transition shadow-md cursor-pointer flex items-center justify-center w-9 h-9"
                title="Close Viewer (Esc)"
              >
                <X size={16} />
              </button>
            </div>
          </div>

          {/* Lightbox Central Display Area */}
          <div 
            className="flex-1 flex items-center justify-center relative overflow-hidden my-4"
            onTouchStart={handleTouchStart}
            onTouchEnd={(e) => handleTouchEnd(
              e, 
              () => {
                setLightboxIndex((prev) => (prev + 1) % property.images.length);
                setLightboxZoom(false);
              },
              () => {
                setLightboxIndex((prev) => (prev - 1 + property.images.length) % property.images.length);
                setLightboxZoom(false);
              }
            )}
          >
            {/* Left Nav Arrow */}
            {property.images.length > 1 && (
              <button
                onClick={() => {
                  setLightboxIndex((prev) => (prev - 1 + property.images.length) % property.images.length);
                  setLightboxZoom(false);
                }}
                className="absolute left-2 md:left-6 z-10 bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-white p-3 md:p-4 rounded-full shadow-2xl transition cursor-pointer flex items-center justify-center"
              >
                <ChevronLeft size={24} />
              </button>
            )}

            {/* Main Lightbox Image */}
            <div className={`transition-all duration-300 max-w-full max-h-[70vh] md:max-h-[75vh] flex items-center justify-center ${
              lightboxZoom ? 'scale-125 md:scale-150 cursor-zoom-out' : 'scale-100 cursor-zoom-in'
            }`}
            onClick={() => setLightboxZoom(!lightboxZoom)}
            >
              <img
                src={property.images[lightboxIndex]}
                alt={`${property.title} - Full View ${lightboxIndex + 1}`}
                referrerPolicy="no-referrer"
                className="rounded-2xl max-w-full max-h-[70vh] md:max-h-[75vh] object-contain shadow-2xl"
              />
            </div>

            {/* Right Nav Arrow */}
            {property.images.length > 1 && (
              <button
                onClick={() => {
                  setLightboxIndex((prev) => (prev + 1) % property.images.length);
                  setLightboxZoom(false);
                }}
                className="absolute right-2 md:right-6 z-10 bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-white p-3 md:p-4 rounded-full shadow-2xl transition cursor-pointer flex items-center justify-center"
              >
                <ChevronRight size={24} />
              </button>
            )}
          </div>

          {/* Lightbox Bottom Thumbnails Ribbon */}
          {property.images.length > 1 && (
            <div className="z-10 bg-slate-900/60 p-4 rounded-3xl border border-slate-800 max-w-3xl mx-auto w-full">
              <div className="flex gap-2.5 justify-center overflow-x-auto pb-1">
                {property.images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => {
                      setLightboxIndex(i);
                      setLightboxZoom(false);
                    }}
                    className={`w-16 h-12 md:w-20 md:h-14 rounded-lg overflow-hidden border shrink-0 transition-all relative ${
                      lightboxIndex === i ? 'border-sky-500 ring-2 ring-sky-500/20' : 'border-slate-800 hover:border-slate-600'
                    }`}
                  >
                    <img src={img} alt={`Lightbox thumb ${i}`} className="w-full h-full object-cover" />
                    {lightboxIndex !== i && (
                      <div className="absolute inset-0 bg-black/45 hover:bg-transparent transition duration-200" />
                    )}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
