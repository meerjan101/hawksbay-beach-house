/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Umbrella, Phone, Mail, MapPin, Facebook, Instagram, Twitter, MessageSquare } from 'lucide-react';

interface FooterProps {
  onTabChange: (tab: string) => void;
  onOpenPrivacyModal: () => void;
  onOpenTermsModal: () => void;
}

export default function Footer({ onTabChange, onOpenPrivacyModal, onOpenTermsModal }: FooterProps) {
  return (
    <footer className="bg-slate-900 text-white mt-auto pt-16 pb-8 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
        {/* Brand Summary */}
        <div className="space-y-4">
          <button 
            onClick={() => onTabChange('home')}
            className="flex items-center gap-2.5 text-left cursor-pointer hover:opacity-90"
          >
            <div className="bg-sky-600 text-white p-2 rounded-xl">
              <Umbrella size={20} />
            </div>
            <span className="font-extrabold text-lg tracking-tight">
              Hawksbay <span className="font-light text-sky-400">Beach House</span>
            </span>
          </button>
          <p className="text-slate-400 text-sm leading-relaxed">
            Premium Beach House Rentals in Karachi. Experience unparalleled luxury beachfront retreats across Karachi's finest sands.
          </p>
          <div className="flex gap-3 pt-2">
            <a 
              href="https://facebook.com" 
              target="_blank" 
              rel="noreferrer" 
              className="text-slate-400 hover:text-sky-400 transition"
              aria-label="Facebook"
            >
              <Facebook size={18} />
            </a>
            <a 
              href="https://instagram.com" 
              target="_blank" 
              rel="noreferrer" 
              className="text-slate-400 hover:text-sky-400 transition"
              aria-label="Instagram"
            >
              <Instagram size={18} />
            </a>
            <a 
              href="https://twitter.com" 
              target="_blank" 
              rel="noreferrer" 
              className="text-slate-400 hover:text-sky-400 transition"
              aria-label="Twitter"
            >
              <Twitter size={18} />
            </a>
            <a 
              href="https://whatsapp.com" 
              target="_blank" 
              rel="noreferrer" 
              className="text-slate-400 hover:text-sky-400 transition"
              aria-label="WhatsApp"
            >
              <MessageSquare size={18} />
            </a>
          </div>
        </div>

        {/* Explore Destinations */}
        <div>
          <h4 className="font-bold text-sky-400 uppercase tracking-wider text-xs mb-4">Destinations</h4>
          <ul className="space-y-2.5 text-sm font-medium text-slate-400">
            <li>
              <button onClick={() => onTabChange('properties')} className="hover:text-white transition cursor-pointer">Hawksbay Beach</button>
            </li>
            <li>
              <button onClick={() => onTabChange('properties')} className="hover:text-white transition cursor-pointer">Sandspit Beach</button>
            </li>
            <li>
              <button onClick={() => onTabChange('properties')} className="hover:text-white transition cursor-pointer">Turtle Beach</button>
            </li>
            <li>
              <button onClick={() => onTabChange('properties')} className="hover:text-white transition cursor-pointer">French Beach</button>
            </li>
          </ul>
        </div>

        {/* Quick Help & Company */}
        <div>
          <h4 className="font-bold text-sky-400 uppercase tracking-wider text-xs mb-4">Company & Info</h4>
          <ul className="space-y-2.5 text-sm font-medium text-slate-400">
            <li>
              <button onClick={() => onTabChange('home')} className="hover:text-white transition cursor-pointer">About Us</button>
            </li>
            <li>
              <button onClick={onOpenPrivacyModal} className="hover:text-white transition cursor-pointer text-left">Privacy Policy</button>
            </li>
            <li>
              <button onClick={onOpenTermsModal} className="hover:text-white transition cursor-pointer text-left">Terms & Conditions</button>
            </li>
            <li>
              <button onClick={() => onTabChange('contact')} className="hover:text-white transition cursor-pointer">Contact Us</button>
            </li>
          </ul>
        </div>

        {/* Corporate Details */}
        <div className="space-y-4">
          <h4 className="font-bold text-sky-400 uppercase tracking-wider text-xs mb-1">Corporate Details</h4>
          <ul className="space-y-3 text-sm text-slate-400">
            <li className="flex items-start gap-2.5">
              <MapPin size={16} className="text-sky-400 mt-0.5 shrink-0" />
              <span className="leading-relaxed">Hawksbay Shoreline Road, Block B, Mauripur, Karachi, Pakistan</span>
            </li>
            <li className="flex items-center gap-2.5">
              <Phone size={16} className="text-sky-400 shrink-0" />
              <span>+92 300 1234567</span>
            </li>
            <li className="flex items-center gap-2.5">
              <Mail size={16} className="text-sky-400 shrink-0" />
              <span>info@hawksbaybeachhouse.com</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 border-t border-slate-800 pt-8 flex flex-col sm:flex-row justify-between items-center gap-4 text-xs text-slate-500">
        <p>© 2026 Hawksbay Beach House. All Rights Reserved. Managed professionally for premium coastal bookings.</p>
        <div className="flex items-center gap-1 text-[11px] text-slate-400">
          <span>Karachi Coastal Sanctuary</span>
        </div>
      </div>
    </footer>
  );
}
