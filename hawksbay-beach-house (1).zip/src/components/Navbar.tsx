/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Umbrella, LogOut, User as UserIcon, LayoutDashboard } from 'lucide-react';
import { User } from '../types';

interface NavbarProps {
  currentUser: User | null;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onLoginClick: () => void;
  onLogout: () => void;
}

export default function Navbar({
  currentUser,
  activeTab,
  setActiveTab,
  onLoginClick,
  onLogout
}: NavbarProps) {
  return (
    <header className="bg-white border-b border-slate-100 sticky top-0 z-50 shadow-sm">
      <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
        {/* Brand Logo */}
        <button 
          onClick={() => setActiveTab('home')}
          className="flex items-center gap-2.5 hover:opacity-90 transition text-left cursor-pointer"
        >
          <div className="bg-sky-600 text-white p-2 rounded-2xl shadow-md shadow-sky-100 flex items-center justify-center">
            <Umbrella size={24} />
          </div>
          <div>
            <h1 className="font-black text-xl tracking-tight text-slate-900 leading-none flex items-center gap-1">
              Hawksbay <span className="font-light text-sky-600">Beach House</span>
            </h1>
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1 block">
              Premium Beach House Rentals in Karachi
            </span>
          </div>
        </button>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-8 font-semibold text-sm text-slate-600">
          <button
            onClick={() => setActiveTab('home')}
            className={`cursor-pointer transition-all ${activeTab === 'home' ? 'text-sky-600 font-extrabold' : 'hover:text-sky-600 text-slate-600'}`}
          >
            Home
          </button>
          <button
            onClick={() => setActiveTab('properties')}
            className={`cursor-pointer transition-all ${activeTab === 'properties' ? 'text-sky-600 font-extrabold' : 'hover:text-sky-600 text-slate-600'}`}
          >
            Beach Houses
          </button>
          <button
            onClick={() => setActiveTab('blogs')}
            className={`cursor-pointer transition-all ${activeTab === 'blogs' ? 'text-sky-600 font-extrabold' : 'hover:text-sky-600 text-slate-600'}`}
          >
            Travel Blogs
          </button>
          <button
            onClick={() => setActiveTab('contact')}
            className={`cursor-pointer transition-all ${activeTab === 'contact' ? 'text-sky-600 font-extrabold' : 'hover:text-sky-600 text-slate-600'}`}
          >
            Contact Us
          </button>
        </nav>

        {/* User Account State */}
        <div className="flex items-center gap-4">
          {currentUser && (currentUser.role === 'Admin' || currentUser.role === 'Moderator') && (
            <button
              onClick={() => setActiveTab('admin')}
              className={`flex items-center gap-1.5 font-bold text-xs uppercase tracking-wider px-4 py-2.5 rounded-2xl shadow-sm border transition-all cursor-pointer ${
                activeTab === 'admin'
                  ? 'bg-sky-600 text-white border-sky-600'
                  : 'bg-white text-sky-700 border-sky-100 hover:bg-sky-50'
              }`}
            >
              <LayoutDashboard size={14} />
              <span>Admin Dashboard</span>
            </button>
          )}

          {currentUser ? (
            <div className="flex items-center gap-3">
              <button
                onClick={() => setActiveTab('profile')}
                className="flex items-center gap-2 text-sm font-semibold text-slate-700 hover:text-sky-600 transition"
              >
                <div className="bg-sky-100 text-sky-700 w-8 h-8 rounded-full flex items-center justify-center font-black">
                  {currentUser.name.charAt(0)}
                </div>
                <span className="hidden lg:inline">{currentUser.name}</span>
              </button>
              <button
                onClick={onLogout}
                className="bg-slate-50 hover:bg-rose-50 text-slate-500 hover:text-rose-600 p-2.5 rounded-2xl border border-slate-100 transition cursor-pointer"
                title="Sign Out"
              >
                <LogOut size={16} />
              </button>
            </div>
          ) : (
            <button
              onClick={onLoginClick}
              className="bg-sky-600 hover:bg-sky-850 text-white font-extrabold text-xs uppercase tracking-wider px-5 py-3 rounded-2xl shadow-lg shadow-sky-100 hover:shadow-xl transition cursor-pointer"
            >
              Portal Login
            </button>
          )}
        </div>
      </div>
    </header>
  );
}
