/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Bed, Bath, Users, Shield, Star, Waves, Flame, Award } from 'lucide-react';
import { Property } from '../types';

interface PropertyCardProps {
  key?: string | number;
  property: Property;
  viewMode: 'grid' | 'list';
  onSelect: (propertyId: string) => void;
  isFavorite: boolean;
  onToggleFavorite: (propertyId: string, e: React.MouseEvent) => void;
}

export default function PropertyCard({
  property,
  viewMode,
  onSelect,
  isFavorite,
  onToggleFavorite
}: PropertyCardProps) {
  const isGrid = viewMode === 'grid';

  // Average rating calculated (all listings default around 4.8 - 4.9 for high fidelity visual style)
  const score = property.featured ? 4.9 : 4.8;

  return (
    <div
      onClick={() => onSelect(property.id)}
      className={`bg-white rounded-3xl border border-slate-100 overflow-hidden shadow-sm hover:shadow-xl hover:border-sky-100 transition-all duration-300 group cursor-pointer flex ${
        isGrid ? 'flex-col h-full' : 'flex-col md:flex-row h-auto gap-4 md:gap-0'
      }`}
    >
      {/* Property Image Container */}
      <div className={`relative overflow-hidden shrink-0 ${isGrid ? 'h-64 w-full' : 'h-64 w-full md:w-[350px]'}`}>
        <img
          src={property.images[0]}
          alt={property.title}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover group-hover:scale-105 transition-all duration-500"
        />
        {/* Badges */}
        <div className="absolute top-4 left-4 flex flex-col gap-1.5">
          {property.featured && (
            <span className="bg-sky-600 text-white font-extrabold text-[10px] uppercase tracking-wider px-3 py-1 rounded-full shadow-sm flex items-center gap-1">
              <Award size={11} />
              <span>Premium Select</span>
            </span>
          )}
          {property.hasPool && (
            <span className="bg-emerald-600 text-white font-extrabold text-[10px] uppercase tracking-wider px-3 py-1 rounded-full shadow-sm flex items-center gap-1">
              <Waves size={11} />
              <span>Private Pool</span>
            </span>
          )}
        </div>

        {/* Favorite Heart Toggle */}
        <button
          onClick={(e) => onToggleFavorite(property.id, e)}
          className="absolute top-4 right-4 bg-white/90 hover:bg-white text-rose-500 p-2 rounded-2xl shadow-sm hover:scale-110 transition cursor-pointer flex items-center justify-center border border-slate-100"
        >
          <Star
            size={16}
            fill={isFavorite ? 'currentColor' : 'none'}
            className={isFavorite ? 'text-rose-500' : 'text-slate-400'}
          />
        </button>

        {/* Location tag at bottom of image */}
        <div className="absolute bottom-4 left-4 bg-slate-900/80 backdrop-blur-sm text-white text-[11px] font-black uppercase tracking-widest px-3.5 py-1.5 rounded-xl flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-sky-400 animate-pulse"></span>
          <span>{property.location}</span>
        </div>
      </div>

      {/* Property Information Body */}
      <div className="p-6 flex-1 flex flex-col justify-between">
        <div>
          {/* Header row with average ratings and bed details */}
          <div className="flex justify-between items-center mb-2">
            <span className="text-[10px] font-black text-sky-600 tracking-widest uppercase flex items-center gap-1">
              <Shield size={12} className="text-sky-500" />
              <span>Secured Compound</span>
            </span>
            <div className="flex items-center gap-1 text-slate-800 text-xs font-black">
              <Star size={12} className="text-amber-500 fill-amber-500" />
              <span>{score}</span>
            </div>
          </div>

          <h3 className="text-xl font-bold text-slate-900 group-hover:text-sky-600 transition duration-200 line-clamp-1 mb-2">
            {property.title}
          </h3>

          <p className="text-slate-500 text-sm line-clamp-2 leading-relaxed mb-4">
            {property.description}
          </p>

          {/* Core specs list */}
          <div className="grid grid-cols-3 gap-3 border-t border-b border-slate-50 py-3.5 mb-5 text-xs font-bold text-slate-500">
            <div className="flex items-center gap-1.5 justify-center">
              <Bed size={14} className="text-sky-600" />
              <span>{property.bedrooms} Bed</span>
            </div>
            <div className="flex items-center gap-1.5 justify-center">
              <Bath size={14} className="text-sky-600" />
              <span>{property.bathrooms} Bath</span>
            </div>
            <div className="flex items-center gap-1.5 justify-center">
              <Users size={14} className="text-sky-600" />
              <span>{property.guestCapacity} Max</span>
            </div>
          </div>

          {/* Quick Icons */}
          <div className="flex flex-wrap gap-1.5 mb-5">
            {property.hasBeachView && (
              <span className="bg-sky-50 text-sky-700 text-[10px] font-extrabold px-2.5 py-1 rounded-lg">
                Beach View
              </span>
            )}
            {property.hasBBQ && (
              <span className="bg-amber-50 text-amber-800 text-[10px] font-extrabold px-2.5 py-1 rounded-lg flex items-center gap-0.5">
                <Flame size={10} className="text-amber-500 fill-amber-500" />
                <span>BBQ Area</span>
              </span>
            )}
            {property.isFamilyFriendly && (
              <span className="bg-indigo-50 text-indigo-700 text-[10px] font-extrabold px-2.5 py-1 rounded-lg">
                Family Safe
              </span>
            )}
          </div>
        </div>

        {/* Price and Book button row */}
        <div className="flex justify-between items-center border-t border-slate-50 pt-4">
          <div>
            <span className="text-2xl font-black text-slate-900">PKR {property.pricePerNight.toLocaleString()}</span>
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block mt-0.5">per night</span>
          </div>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onSelect(property.id);
            }}
            className="bg-sky-600 hover:bg-sky-800 text-white text-xs font-black uppercase tracking-wider px-5 py-3 rounded-2xl shadow-md hover:shadow-lg transition duration-200 cursor-pointer"
          >
            Book Now
          </button>
        </div>
      </div>
    </div>
  );
}
