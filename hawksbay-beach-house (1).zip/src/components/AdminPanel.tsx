/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Building, Calendar, Star, BookOpen, Settings, Check, X, ShieldAlert, 
  Trash2, Plus, MessageCircle, DollarSign, Users, Info, MapPin, Edit
} from 'lucide-react';
import { Property, Booking, Review, Blog, WebsiteSettings } from '../types';

interface AdminPanelProps {
  properties: Property[];
  bookings: Booking[];
  reviews: Review[];
  blogs: Blog[];
  settings: WebsiteSettings;
  currentRole: 'Moderator' | 'Admin';
  onUpdateBookingStatus: (bookingId: string, status: Booking['status']) => void;
  onUpdatePaymentStatus: (bookingId: string, status: Booking['paymentStatus']) => void;
  onApproveReview: (reviewId: string) => void;
  onDeleteReview: (reviewId: string) => void;
  onAddProperty: (property: Property) => void;
  onDeleteProperty: (propertyId: string) => void;
  onAddBlog: (blog: Blog) => void;
  onDeleteBlog: (blogId: string) => void;
  onUpdateSettings: (settings: WebsiteSettings) => void;
}

export default function AdminPanel({
  properties,
  bookings,
  reviews,
  blogs,
  settings,
  currentRole,
  onUpdateBookingStatus,
  onUpdatePaymentStatus,
  onApproveReview,
  onDeleteReview,
  onAddProperty,
  onDeleteProperty,
  onAddBlog,
  onDeleteBlog,
  onUpdateSettings
}: AdminPanelProps) {
  const [activeSubTab, setActiveSubTab] = useState<'dashboard' | 'bookings' | 'properties' | 'reviews' | 'blogs' | 'settings'>('dashboard');

  // Form states
  const [showPropForm, setShowPropForm] = useState(false);
  const [newProp, setNewProp] = useState<Omit<Property, 'id'>>({
    title: '',
    description: '',
    pricePerNight: 40000,
    location: 'Hawksbay, Block A',
    bedrooms: 3,
    bathrooms: 3,
    guestCapacity: 15,
    hasPool: true,
    hasBBQ: true,
    hasBeachView: true,
    isFamilyFriendly: true,
    images: ['https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=1200&q=80'],
    amenities: ['Air Conditioning', 'Standby Generator', '24/7 Security Guard', 'WiFi', 'Private Pool', 'BBQ Grill'],
    houseRules: ['No pets inside', 'Quiet hours from 10 PM', 'Keep shoreline clean'],
    featured: false
  });

  const [showBlogForm, setShowBlogForm] = useState(false);
  const [newBlog, setNewBlog] = useState<Omit<Blog, 'id' | 'date'>>({
    title: '',
    excerpt: '',
    content: '',
    category: 'Travel Guides',
    tags: ['Beach', 'Guides', 'Karachi'],
    author: 'Karachi Beach Host',
    readTime: '4 min read',
    image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&w=800&q=80'
  });

  const [editSettings, setEditSettings] = useState<WebsiteSettings>({ ...settings });
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Core metrics
  const totalRevenue = bookings
    .filter(b => b.paymentStatus === 'Paid' || b.paymentStatus === 'Partially Paid')
    .reduce((sum, b) => sum + b.totalPrice, 0);

  const pendingBookings = bookings.filter(b => b.status === 'Pending').length;
  const pendingReviews = reviews.filter(r => !r.approved).length;

  const showNotification = (msg: string) => {
    setSuccessMessage(msg);
    setTimeout(() => {
      setSuccessMessage(null);
    }, 4000);
  };

  const handlePropertySubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const id = 'hb-' + (properties.length + 1);
    onAddProperty({ ...newProp, id });
    setShowPropForm(false);
    showNotification('Beach House property listing registered successfully!');
  };

  const handleBlogSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const id = 'blog-' + (blogs.length + 1);
    const date = new Date().toISOString().split('T')[0];
    onAddBlog({ ...newBlog, id, date });
    setShowBlogForm(false);
    showNotification('Blog post published successfully!');
  };

  const handleSettingsSave = (e: React.FormEvent) => {
    e.preventDefault();
    onUpdateSettings(editSettings);
    showNotification('Website configuration stored successfully!');
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-8">
      {/* Success Notification Banner */}
      {successMessage && (
        <div className="mb-6 bg-emerald-50 border border-emerald-100 text-emerald-800 px-5 py-4 rounded-2xl flex items-center gap-3 font-bold text-sm shadow-sm">
          <Check size={18} className="text-emerald-600 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {/* Admin Header Info */}
      <div className="bg-gradient-to-r from-sky-900 to-sky-800 text-white p-8 rounded-3xl shadow-md mb-8 flex justify-between items-center flex-wrap gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="bg-sky-500/20 text-sky-300 font-extrabold text-[10px] uppercase tracking-wider px-3 py-1 rounded-full border border-sky-500/30">
              {currentRole} WORKSPACE
            </span>
            <span className="text-sky-300">•</span>
            <span className="text-xs font-semibold text-sky-100">Hawksbay Beach House Control Panel</span>
          </div>
          <h1 className="text-3xl font-black tracking-tight mt-2.5">
            Ahlan wa Sahlan, Controller!
          </h1>
          <p className="text-sky-200 text-sm mt-1 max-w-lg font-medium">
            Manage your Karachi coastal rentals, review bookings, moderate customer reviews, and edit portal details here.
          </p>
        </div>

        {/* Quick Nav Pill buttons */}
        <div className="flex flex-wrap gap-2">
          {[
            { id: 'dashboard', label: 'Overview', icon: Building },
            { id: 'bookings', label: 'Bookings', icon: Calendar },
            { id: 'properties', label: 'Properties', icon: Building },
            { id: 'reviews', label: 'Reviews', icon: Star },
            { id: 'blogs', label: 'Blogs', icon: BookOpen },
            { id: 'settings', label: 'Settings', icon: Settings }
          ].map((item) => {
            const Icon = item.icon;
            // Moderator restrictions check
            if (currentRole === 'Moderator' && item.id === 'settings') return null;

            return (
              <button
                key={item.id}
                onClick={() => setActiveSubTab(item.id as any)}
                className={`flex items-center gap-2 px-4.5 py-3 rounded-2xl text-xs font-black uppercase tracking-wider shadow-sm border transition cursor-pointer ${
                  activeSubTab === item.id
                    ? 'bg-white text-sky-900 border-white font-extrabold'
                    : 'bg-sky-950/40 text-sky-100 border-sky-800 hover:bg-sky-850'
                }`}
              >
                <Icon size={14} />
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* SUB-TABS VIEWS RENDERING */}

      {/* 1. Dashboard Tab */}
      {activeSubTab === 'dashboard' && (
        <div className="space-y-10">
          {/* Bento-grid of statistical metrics */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex items-center gap-5">
              <div className="bg-sky-50 text-sky-600 p-4 rounded-2xl">
                <DollarSign size={24} />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Estimated Revenue</span>
                <span className="text-2xl font-black text-slate-900 mt-1 block">PKR {totalRevenue.toLocaleString()}</span>
              </div>
            </div>

            <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex items-center gap-5">
              <div className="bg-sky-50 text-sky-600 p-4 rounded-2xl">
                <Calendar size={24} />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Total Bookings</span>
                <span className="text-2xl font-black text-slate-900 mt-1 block">{bookings.length} Requests</span>
              </div>
            </div>

            <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex items-center gap-5">
              <div className="bg-amber-50 text-amber-600 p-4 rounded-2xl">
                <Star size={24} />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Pending Reviews</span>
                <span className="text-2xl font-black text-slate-900 mt-1 block">
                  {pendingReviews} <span className="text-xs font-semibold text-rose-500">({pendingReviews} to moderate)</span>
                </span>
              </div>
            </div>

            <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm flex items-center gap-5">
              <div className="bg-emerald-50 text-emerald-600 p-4 rounded-2xl">
                <Users size={24} />
              </div>
              <div>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">Pending Bookings</span>
                <span className="text-2xl font-black text-slate-900 mt-1 block">
                  {pendingBookings} <span className="text-xs font-semibold text-sky-500">({pendingBookings} active)</span>
                </span>
              </div>
            </div>
          </div>

          {/* Quick Analytics Simulation charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
              <h3 className="font-extrabold text-slate-900 text-lg mb-6">Booking Popularity by Destination</h3>
              <div className="space-y-4">
                {[
                  { name: 'Hawksbay Beach', count: 12, percent: '75%', color: 'bg-sky-600' },
                  { name: 'Sandspit Beach', count: 8, percent: '50%', color: 'bg-emerald-500' },
                  { name: 'Turtle Beach', count: 6, percent: '38%', color: 'bg-amber-500' },
                  { name: 'French Beach', count: 4, percent: '25%', color: 'bg-purple-500' }
                ].map((item, index) => (
                  <div key={index} className="space-y-1.5">
                    <div className="flex justify-between text-xs font-bold text-slate-600">
                      <span>{item.name}</span>
                      <span>{item.count} Bookings</span>
                    </div>
                    <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                      <div className={`${item.color} h-full rounded-full`} style={{ width: item.percent }}></div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm flex flex-col justify-between">
              <div>
                <h3 className="font-extrabold text-slate-900 text-lg mb-2">Operations Guide Lines</h3>
                <p className="text-slate-500 text-sm leading-relaxed mb-4">
                  Please remember that Hawksbay Beach House uses a <strong>"Pay on Arrival"</strong> system. Be sure to check WhatsApp details of customers upon booking submission and manually log payment status as "Paid" or "Partially Paid" once deposit is wired.
                </p>
              </div>
              <div className="bg-sky-50 p-4 rounded-2xl text-xs text-sky-800 leading-relaxed border border-sky-100 flex gap-2">
                <Info size={16} className="text-sky-600 shrink-0" />
                <span>Moderators can fully review bookings, approve reviews, and post guides. Website global settings requires full Admin role.</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. Bookings Tab */}
      {activeSubTab === 'bookings' && (
        <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-50 flex justify-between items-center">
            <h3 className="font-extrabold text-slate-900 text-lg">Booking Requests Logs ({bookings.length})</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 text-[10px] font-black text-slate-400 uppercase tracking-wider border-b border-slate-100">
                  <th className="p-6">ID / PROPERTY</th>
                  <th className="p-6">GUEST INFO</th>
                  <th className="p-6">STAY DATES</th>
                  <th className="p-6">PRICE</th>
                  <th className="p-6">STATUS</th>
                  <th className="p-6 text-right">ACTIONS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50 text-sm font-semibold">
                {bookings.map((booking) => (
                  <tr key={booking.id} className="hover:bg-slate-50/50">
                    <td className="p-6">
                      <div className="text-slate-900 font-extrabold">{booking.id}</div>
                      <div className="text-slate-400 text-xs font-bold mt-1 uppercase tracking-wider">{booking.propertyName}</div>
                    </td>
                    <td className="p-6">
                      <div className="text-slate-900 font-bold">{booking.guestName}</div>
                      <div className="text-slate-400 text-xs mt-0.5">{booking.guestEmail}</div>
                      <div className="text-slate-500 font-medium text-xs mt-0.5">{booking.guestPhone}</div>
                    </td>
                    <td className="p-6">
                      <div className="text-slate-800 font-bold">{booking.checkIn} to {booking.checkOut}</div>
                      <div className="text-[10px] text-slate-400 uppercase font-black tracking-widest mt-0.5">{booking.guests} Guests limit</div>
                    </td>
                    <td className="p-6">
                      <div className="text-slate-950 font-black">PKR {booking.totalPrice.toLocaleString()}</div>
                    </td>
                    <td className="p-6">
                      {/* Booking status badge & Payment badge */}
                      <div className="space-y-1">
                        <span className={`inline-block px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                          booking.status === 'Approved' ? 'bg-emerald-50 text-emerald-700' :
                          booking.status === 'Pending' ? 'bg-sky-50 text-sky-700 animate-pulse' :
                          booking.status === 'Rejected' ? 'bg-rose-50 text-rose-600' :
                          'bg-slate-100 text-slate-600'
                        }`}>
                          {booking.status}
                        </span>
                        <div className="flex items-center gap-1.5">
                          <span className="text-[9px] text-slate-400 uppercase font-bold">Payment:</span>
                          <span className={`text-[9px] font-black uppercase ${
                            booking.paymentStatus === 'Paid' ? 'text-emerald-600' :
                            booking.paymentStatus === 'Partially Paid' ? 'text-amber-600' :
                            'text-rose-500'
                          }`}>{booking.paymentStatus}</span>
                        </div>
                      </div>
                    </td>
                    <td className="p-6 text-right">
                      {/* Action buttons */}
                      <div className="flex items-center justify-end gap-2 flex-wrap">
                        {booking.status === 'Pending' && (
                          <>
                            <button
                              onClick={() => onUpdateBookingStatus(booking.id, 'Approved')}
                              className="bg-emerald-600 hover:bg-emerald-700 text-white p-2 rounded-xl"
                              title="Approve Booking"
                            >
                              <Check size={14} />
                            </button>
                            <button
                              onClick={() => onUpdateBookingStatus(booking.id, 'Rejected')}
                              className="bg-rose-600 hover:bg-rose-700 text-white p-2 rounded-xl"
                              title="Reject Booking"
                            >
                              <X size={14} />
                            </button>
                          </>
                        )}

                        {booking.status === 'Approved' && (
                          <button
                            onClick={() => onUpdateBookingStatus(booking.id, 'Completed')}
                            className="bg-slate-800 hover:bg-slate-900 text-white text-xs px-2.5 py-1.5 rounded-xl uppercase font-black"
                          >
                            Mark Completed
                          </button>
                        )}

                        {/* Payment Toggle Dropdown simulator */}
                        <select
                          value={booking.paymentStatus}
                          onChange={(e) => onUpdatePaymentStatus(booking.id, e.target.value as any)}
                          className="bg-slate-50 border border-slate-200 text-slate-600 text-[11px] font-bold px-2 py-1.5 rounded-xl focus:border-sky-500 focus:ring-1 focus:ring-sky-500"
                        >
                          <option value="Pending">Unpaid</option>
                          <option value="Partially Paid">Deposit Rec.</option>
                          <option value="Paid">Fully Paid</option>
                          <option value="Refunded">Refunded</option>
                        </select>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 3. Properties Tab */}
      {activeSubTab === 'properties' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="font-extrabold text-slate-900 text-lg">Manage Beach Houses ({properties.length})</h3>
            <button
              onClick={() => setShowPropForm(true)}
              className="bg-sky-600 hover:bg-sky-800 text-white font-extrabold text-xs uppercase tracking-wider px-5 py-3 rounded-2xl shadow-md flex items-center gap-1.5 cursor-pointer"
            >
              <Plus size={14} />
              <span>Add Beach House</span>
            </button>
          </div>

          {/* Add property form modal/collapse */}
          {showPropForm && (
            <form onSubmit={handlePropertySubmit} className="bg-white p-8 rounded-3xl border border-sky-100 shadow-xl space-y-6">
              <h3 className="font-extrabold text-slate-900 text-base">Register New Beach House</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">PROPERTY TITLE</label>
                  <input
                    type="text"
                    required
                    value={newProp.title}
                    onChange={(e) => setNewProp({ ...newProp, title: e.target.value })}
                    placeholder="e.g., Sea Breeze Villa"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:border-sky-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">LOCATION</label>
                  <select
                    value={newProp.location}
                    onChange={(e) => setNewProp({ ...newProp, location: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:border-sky-500"
                  >
                    <option value="Hawksbay, Block A">Hawksbay, Block A</option>
                    <option value="Hawksbay, Block B">Hawksbay, Block B</option>
                    <option value="Sandspit Beach">Sandspit Beach</option>
                    <option value="Turtle Beach">Turtle Beach</option>
                    <option value="French Beach">French Beach</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">PRICE PER NIGHT (PKR)</label>
                  <input
                    type="number"
                    required
                    value={newProp.pricePerNight}
                    onChange={(e) => setNewProp({ ...newProp, pricePerNight: Number(e.target.value) })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:border-sky-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">BEDROOMS</label>
                  <input
                    type="number"
                    required
                    value={newProp.bedrooms}
                    onChange={(e) => setNewProp({ ...newProp, bedrooms: Number(e.target.value) })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">BATHROOMS</label>
                  <input
                    type="number"
                    required
                    value={newProp.bathrooms}
                    onChange={(e) => setNewProp({ ...newProp, bathrooms: Number(e.target.value) })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">MAX CAPACITY</label>
                  <input
                    type="number"
                    required
                    value={newProp.guestCapacity}
                    onChange={(e) => setNewProp({ ...newProp, guestCapacity: Number(e.target.value) })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">IMAGE URL</label>
                  <input
                    type="text"
                    required
                    value={newProp.images[0]}
                    onChange={(e) => setNewProp({ ...newProp, images: [e.target.value] })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">DESCRIPTION</label>
                <textarea
                  rows={3}
                  required
                  value={newProp.description}
                  onChange={(e) => setNewProp({ ...newProp, description: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:border-sky-500"
                ></textarea>
              </div>

              {/* Boolean toggles */}
              <div className="flex gap-6 flex-wrap text-sm font-semibold">
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={newProp.hasPool}
                    onChange={(e) => setNewProp({ ...newProp, hasPool: e.target.checked })}
                    className="rounded border-slate-300 text-sky-600 focus:ring-sky-500"
                  />
                  <span>Has Swimming Pool</span>
                </label>
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={newProp.hasBBQ}
                    onChange={(e) => setNewProp({ ...newProp, hasBBQ: e.target.checked })}
                    className="rounded border-slate-300 text-sky-600 focus:ring-sky-500"
                  />
                  <span>Has BBQ Deck</span>
                </label>
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={newProp.hasBeachView}
                    onChange={(e) => setNewProp({ ...newProp, hasBeachView: e.target.checked })}
                    className="rounded border-slate-300 text-sky-600 focus:ring-sky-500"
                  />
                  <span>Has Sea View</span>
                </label>
                <label className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={newProp.isFamilyFriendly}
                    onChange={(e) => setNewProp({ ...newProp, isFamilyFriendly: e.target.checked })}
                    className="rounded border-slate-300 text-sky-600 focus:ring-sky-500"
                  />
                  <span>Family Safe Compound</span>
                </label>
              </div>

              <div className="flex gap-2">
                <button
                  type="submit"
                  className="bg-sky-600 hover:bg-sky-800 text-white font-extrabold text-xs uppercase tracking-wider px-6 py-3.5 rounded-2xl shadow-md transition cursor-pointer"
                >
                  Save Listing
                </button>
                <button
                  type="button"
                  onClick={() => setShowPropForm(false)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-600 font-extrabold text-xs uppercase tracking-wider px-6 py-3.5 rounded-2xl transition cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </form>
          )}

          {/* Listings Table representation */}
          <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 text-[10px] font-black text-slate-400 uppercase tracking-wider border-b border-slate-100">
                  <th className="p-6">PREVIEW / TITLE</th>
                  <th className="p-6">LOCATION</th>
                  <th className="p-6">SPECS</th>
                  <th className="p-6">PRICE PER NIGHT</th>
                  <th className="p-6 text-right">ACTIONS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50 text-sm font-semibold">
                {properties.map((prop) => (
                  <tr key={prop.id} className="hover:bg-slate-50/50">
                    <td className="p-6 flex items-center gap-4">
                      <img src={prop.images[0]} alt={prop.title} className="w-16 h-12 rounded-xl object-cover border" />
                      <div>
                        <div className="text-slate-900 font-extrabold">{prop.title}</div>
                        <div className="text-slate-400 text-xs mt-0.5">{prop.id}</div>
                      </div>
                    </td>
                    <td className="p-6 text-slate-700">
                      <span>{prop.location}</span>
                    </td>
                    <td className="p-6 text-slate-500 text-xs">
                      <span>{prop.bedrooms} Bed • {prop.bathrooms} Bath • Max {prop.guestCapacity} guests</span>
                    </td>
                    <td className="p-6 text-slate-900 font-black">
                      <span>PKR {prop.pricePerNight.toLocaleString()}</span>
                    </td>
                    <td className="p-6 text-right">
                      <button
                        onClick={() => onDeleteProperty(prop.id)}
                        className="bg-rose-50 text-rose-600 hover:bg-rose-100 p-2.5 rounded-xl border border-rose-100 hover:border-rose-300 transition cursor-pointer"
                        title="Delete Property"
                      >
                        <Trash2 size={14} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 4. Reviews Tab */}
      {activeSubTab === 'reviews' && (
        <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-50">
            <h3 className="font-extrabold text-slate-900 text-lg">Moderate Reviews & Feedbacks ({reviews.length})</h3>
          </div>
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-slate-50 text-[10px] font-black text-slate-400 uppercase tracking-wider border-b border-slate-100">
                <th className="p-6">PROPERTY / AUTHOR</th>
                <th className="p-6">RATING & COMMENT</th>
                <th className="p-6">STATUS</th>
                <th className="p-6 text-right">ACTIONS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50 text-sm font-semibold">
              {reviews.map((rev) => (
                <tr key={rev.id} className="hover:bg-slate-50/50">
                  <td className="p-6">
                    <div className="text-slate-900 font-extrabold">{rev.propertyName}</div>
                    <div className="text-slate-400 text-xs font-bold mt-1">By: {rev.authorName}</div>
                  </td>
                  <td className="p-6 max-w-sm">
                    <div className="flex gap-0.5 text-amber-500 mb-1.5">
                      {Array.from({ length: rev.rating }).map((_, i) => (
                        <Star key={i} size={11} fill="currentColor" />
                      ))}
                    </div>
                    <p className="text-slate-600 text-xs font-medium leading-relaxed">{rev.comment}</p>
                  </td>
                  <td className="p-6">
                    <span className={`inline-block px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                      rev.approved ? 'bg-emerald-50 text-emerald-700' : 'bg-amber-50 text-amber-700 animate-pulse'
                    }`}>
                      {rev.approved ? 'Approved' : 'Pending Approval'}
                    </span>
                  </td>
                  <td className="p-6 text-right">
                    <div className="flex items-center justify-end gap-2">
                      {!rev.approved && (
                        <button
                          onClick={() => onApproveReview(rev.id)}
                          className="bg-emerald-600 hover:bg-emerald-700 text-white p-2 rounded-xl transition cursor-pointer"
                          title="Approve Review"
                        >
                          <Check size={14} />
                        </button>
                      )}
                      <button
                        onClick={() => onDeleteReview(rev.id)}
                        className="bg-rose-50 text-rose-600 hover:bg-rose-100 p-2 rounded-xl border border-rose-100 transition cursor-pointer"
                        title="Delete Review"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* 5. Blogs Tab */}
      {activeSubTab === 'blogs' && (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <h3 className="font-extrabold text-slate-900 text-lg">Manage Travel Blogs ({blogs.length})</h3>
            <button
              onClick={() => setShowBlogForm(true)}
              className="bg-sky-600 hover:bg-sky-800 text-white font-extrabold text-xs uppercase tracking-wider px-5 py-3 rounded-2xl shadow-md flex items-center gap-1.5 cursor-pointer"
            >
              <Plus size={14} />
              <span>Create Blog Post</span>
            </button>
          </div>

          {showBlogForm && (
            <form onSubmit={handleBlogSubmit} className="bg-white p-8 rounded-3xl border border-sky-100 shadow-xl space-y-6">
              <h3 className="font-extrabold text-slate-900 text-base">Write New Beach Guide</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">BLOG TITLE</label>
                  <input
                    type="text"
                    required
                    value={newBlog.title}
                    onChange={(e) => setNewBlog({ ...newBlog, title: e.target.value })}
                    placeholder="e.g. Unwinding at Sandspit Coastline"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:border-sky-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">CATEGORY</label>
                  <select
                    value={newBlog.category}
                    onChange={(e) => setNewBlog({ ...newBlog, category: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:border-sky-500"
                  >
                    <option value="Travel Guides">Travel Guides</option>
                    <option value="Rental Tips">Rental Tips</option>
                    <option value="Eco Tourism">Eco Tourism</option>
                    <option value="Lifestyle">Lifestyle</option>
                    <option value="History">History</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">IMAGE URL</label>
                  <input
                    type="text"
                    required
                    value={newBlog.image}
                    onChange={(e) => setNewBlog({ ...newBlog, image: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">READ TIME</label>
                  <input
                    type="text"
                    required
                    value={newBlog.readTime}
                    onChange={(e) => setNewBlog({ ...newBlog, readTime: e.target.value })}
                    placeholder="e.g. 5 min read"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">TAGS (COMMA SEPARATED)</label>
                  <input
                    type="text"
                    required
                    value={newBlog.tags.join(', ')}
                    onChange={(e) => setNewBlog({ ...newBlog, tags: e.target.value.split(',').map(t => t.trim()) })}
                    placeholder="Karachi, Sandspit, Guide"
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">EXCERPT (SHORT SUMMARY)</label>
                <input
                  type="text"
                  required
                  value={newBlog.excerpt}
                  onChange={(e) => setNewBlog({ ...newBlog, excerpt: e.target.value })}
                  placeholder="Summarize the article in one sentence..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">FULL ARTICLE CONTENT</label>
                <textarea
                  rows={6}
                  required
                  value={newBlog.content}
                  onChange={(e) => setNewBlog({ ...newBlog, content: e.target.value })}
                  placeholder="Markdown or normal text format here..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:border-sky-500"
                ></textarea>
              </div>

              <div className="flex gap-2">
                <button
                  type="submit"
                  className="bg-sky-600 hover:bg-sky-800 text-white font-extrabold text-xs uppercase tracking-wider px-6 py-3.5 rounded-2xl shadow-md transition cursor-pointer"
                >
                  Publish Article
                </button>
                <button
                  type="button"
                  onClick={() => setShowBlogForm(false)}
                  className="bg-slate-100 hover:bg-slate-200 text-slate-600 font-extrabold text-xs uppercase tracking-wider px-6 py-3.5 rounded-2xl transition cursor-pointer"
                >
                  Cancel
                </button>
              </div>
            </form>
          )}

          <div className="bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 text-[10px] font-black text-slate-400 uppercase tracking-wider border-b border-slate-100">
                  <th className="p-6">COVER / TITLE</th>
                  <th className="p-6">CATEGORY</th>
                  <th className="p-6">DATE</th>
                  <th className="p-6">READ TIME</th>
                  <th className="p-6 text-right">ACTIONS</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50 text-sm font-semibold">
                {blogs.map((blog) => (
                  <tr key={blog.id} className="hover:bg-slate-50/50">
                    <td className="p-6 flex items-center gap-4">
                      <img src={blog.image} alt={blog.title} className="w-16 h-12 rounded-xl object-cover border" />
                      <div>
                        <div className="text-slate-900 font-extrabold line-clamp-1">{blog.title}</div>
                        <div className="text-slate-400 text-xs mt-0.5">{blog.id}</div>
                      </div>
                    </td>
                    <td className="p-6 text-slate-600">{blog.category}</td>
                    <td className="p-6 text-slate-500 text-xs">{blog.date}</td>
                    <td className="p-6 text-slate-500 text-xs">{blog.readTime}</td>
                    <td className="p-6 text-right">
                      <button
                        onClick={() => onDeleteBlog(blog.id)}
                        className="bg-rose-50 text-rose-600 hover:bg-rose-100 p-2.5 rounded-xl border border-rose-100 hover:border-rose-300 transition cursor-pointer"
                        title="Delete Article"
                      >
                        <Trash2 size={14} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 6. Settings Tab */}
      {activeSubTab === 'settings' && (
        <form onSubmit={handleSettingsSave} className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm space-y-6">
          <h3 className="font-extrabold text-slate-900 text-lg border-b border-slate-50 pb-4">Global Website Settings</h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-xs font-bold text-slate-500 mb-1">PORTAL NAME</label>
              <input
                type="text"
                required
                value={editSettings.siteName}
                onChange={(e) => setEditSettings({ ...editSettings, siteName: e.target.value })}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:border-sky-500 font-semibold"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 mb-1">SUPPORT WHATSAPP (NO PLUSSES/SPACES)</label>
              <input
                type="text"
                required
                value={editSettings.whatsapp}
                onChange={(e) => setEditSettings({ ...editSettings, whatsapp: e.target.value })}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:border-sky-500 font-semibold"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-xs font-bold text-slate-500 mb-1">SUPPORT PHONE</label>
              <input
                type="text"
                required
                value={editSettings.phone}
                onChange={(e) => setEditSettings({ ...editSettings, phone: e.target.value })}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:border-sky-500 font-semibold"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 mb-1">SUPPORT EMAIL</label>
              <input
                type="email"
                required
                value={editSettings.email}
                onChange={(e) => setEditSettings({ ...editSettings, email: e.target.value })}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:border-sky-500 font-semibold"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-500 mb-1">OFFICE ADDRESS</label>
            <input
              type="text"
              required
              value={editSettings.address}
              onChange={(e) => setEditSettings({ ...editSettings, address: e.target.value })}
              className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:border-sky-500 font-semibold"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-xs font-bold text-slate-500 mb-1">HEADER PROMOTION SUBTEXT</label>
              <textarea
                rows={2}
                required
                value={editSettings.headerText}
                onChange={(e) => setEditSettings({ ...editSettings, headerText: e.target.value })}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:border-sky-500 font-semibold"
              ></textarea>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 mb-1">FOOTER LEGAL DECLARATION</label>
              <textarea
                rows={2}
                required
                value={editSettings.footerText}
                onChange={(e) => setEditSettings({ ...editSettings, footerText: e.target.value })}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 text-sm focus:border-sky-500 font-semibold"
              ></textarea>
            </div>
          </div>

          <button
            type="submit"
            className="bg-sky-600 hover:bg-sky-800 text-white font-extrabold text-xs uppercase tracking-wider px-6 py-3.5 rounded-2xl shadow-md transition cursor-pointer"
          >
            Store Website Configuration
          </button>
        </form>
      )}
    </div>
  );
}
